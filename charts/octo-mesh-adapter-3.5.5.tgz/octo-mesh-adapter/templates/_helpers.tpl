
{{/*
Fully qualified app name for adapters.

Under the operator-driven deploy path, .Release.Name is already
`{tenantId}-{workloadName}` (DNS-sanitized and globally unique per
tenant), so the historical `{release}-{chart}-{tenantId}-{adapterRtId}`
suffix was just adding noise to every Pod / Service / Deployment name.
We now use Release.Name verbatim (still truncated to 63 chars for the
DNS-1123 limit). `fullnameOverride` stays as an escape hatch for
out-of-band installs that need a fixed name.
*/}}
{{/*
  AB#4924 — is this release an adapter POOL MEMBER rather than a dedicated adapter?

  Both ids or neither: AdapterPoolMemberOptions.IsEnabled requires both, so half a
  configuration must render as a dedicated adapter rather than as a broken member.
  Emits a non-empty string for true and nothing for false, which is what `if`
  expects. Defined once because three separate places have to agree — they decide
  whether the pod gets a tenant, an adapter RtId, and the cluster's shared data-store
  secrets, and a condition that drifted between them would produce a member that is a
  member in one respect and not in another.
*/}}
{{- define "octo-mesh.isPoolMember" -}}
{{- if and .Values.adapterPool .Values.adapterPool.poolTenantId .Values.adapterPool.poolRtId -}}
true
{{- end -}}
{{- end }}

{{- define "octo-mesh.adapterFullname" -}}
    {{- if .Values.fullnameOverride }}
        {{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" | lower }}
    {{- else }}
        {{- .Release.Name | trunc 63 | trimSuffix "-" | lower }}
    {{- end }}
{{- end }}

{{/*
Expand the name of the chart.
*/}}
{{- define "octo-mesh.name" -}}
{{- default .Chart.Name | trunc 63 | trimSuffix "-" | lower }}
{{- end }}

{{/*
Conventional Helm fullname helper. Aliased to adapterFullname so every
chart-owned resource (Deployment, Service, Ingress, chart-managed Secret)
shares the same DNS-1123 stem and Pods don't end up with three layers
of redundant prefixes.
*/}}
{{- define "octo-mesh.fullname" -}}
{{- include "octo-mesh.adapterFullname" . -}}
{{- end }}

{{/*
Service name. Same simplification as octo-mesh.adapterFullname — the
service shares the deployment's name so the selector labels are stable
without an extra suffix.
*/}}
{{- define "octo-mesh.service-fullname" -}}
{{- include "octo-mesh.adapterFullname" . -}}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "octo-mesh.selectorLabels" -}}
app.kubernetes.io/name: {{ include "octo-mesh.name" . }}
app.kubernetes.io/instance: {{ include "octo-mesh.fullname" . }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "octo-mesh.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "octo-mesh.labels" -}}
helm.sh/chart: {{ include "octo-mesh.chart" . }}
{{ include "octo-mesh.selectorLabels" .  }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels service related
*/}}
{{- define "octo-mesh.service-selectorLabels" -}}
{{ include "octo-mesh.selectorLabels" . }}
app.kubernetes.io/service: {{ include "octo-mesh.service-fullname" . }}
{{- end }}

{{/*
Common labels service related
*/}}
{{- define "octo-mesh.service-labels" -}}
{{ include "octo-mesh.service-selectorLabels" . }}
{{- end }}

{{/*
Check if a mandadory value exists
*/}}
{{- define "checkMandatoryValue" -}}
{{- if not .value -}}
{{- fail (printf "Value %s does not exist. Please define a corresponding value." .name) -}}
{{- end -}}
{{- end -}}

{{/*
Render an env var entry whose value is a secret. The input value supports
two shapes:

  1. string (legacy): the chart packs it into the chart-owned `<fullname>-backend`
     Secret and renders a `valueFrom.secretKeyRef` pointing at that Secret with
     the legacyKey as the key name.
  2. map with `valueFrom`: rendered straight through, so the caller can point
     at an externally-managed Secret (operator-managed `<release>-octo-secrets`,
     External Secrets, etc.).

Anything else fails the template — silent acceptance would mask typos.

Usage:
  {{ include "octo-mesh.secretEnv" (dict
       "envName"   "OCTO_SYSTEM__DATABASEUSERPASSWORD"
       "value"     .Values.secrets.databaseUser
       "legacyKey" "databaseUser"
       "context"   .
  ) }}
*/}}
{{- define "octo-mesh.secretEnv" -}}
- name: {{ .envName }}
{{- if kindIs "map" .value }}
  {{- if hasKey .value "valueFrom" }}
  {{- toYaml .value | nindent 2 }}
  {{- else }}
  {{- fail (printf "secrets.%s must be a string or a {valueFrom: secretKeyRef: ...} map" .legacyKey) }}
  {{- end }}
{{- else if .value }}
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh.fullname" .context) }}
      key: {{ .legacyKey }}
{{- else }}
  {{- fail (printf "secrets.%s must be set (either a plaintext string or a valueFrom map)" .legacyKey) }}
{{- end }}
{{- end -}}

{{/*
Returns "true" when any of the secret fields used by the chart-owned
`<fullname>-backend` Secret is a plaintext string. Used by secret.yaml to
skip emitting the resource entirely when every value is sourced
externally via valueFrom.
*/}}
{{- define "octo-mesh.hasPlaintextBackendSecret" -}}
{{- $s := .Values.secrets -}}
{{- $member := include "octo-mesh.isPoolMember" . -}}
{{- if and (not $member) $s.databaseUser (not (kindIs "map" $s.databaseUser)) -}}true
{{- else if and (not $member) $s.databaseAdmin (not (kindIs "map" $s.databaseAdmin)) -}}true
{{- else if and $s.rabbitmq (not (kindIs "map" $s.rabbitmq)) -}}true
{{- else if and (not $member) $s.streamDataPassword (not (kindIs "map" $s.streamDataPassword)) -}}true
{{- else if and $s.serviceAccountClientSecret (not (kindIs "map" $s.serviceAccountClientSecret)) -}}true
{{- else if and (not $member) (include "octo-mesh.hasPlaintextSecretEncryption" .) -}}true
{{- end -}}
{{- end -}}

{{/*
"true" when any SECRET key ring value (AB#5536) is a plaintext string and therefore
has to be packed into the chart-owned `<fullname>-backend` Secret.
*/}}
{{- define "octo-mesh.hasPlaintextSecretEncryption" -}}
{{- $se := .Values.secrets.secretEncryption | default dict -}}
{{- $found := false -}}
{{- range $kid, $value := ($se.keys | default dict) -}}
{{- if and $value (not (kindIs "map" $value)) -}}{{- $found = true -}}{{- end -}}
{{- end -}}
{{- if and $se.legacyV1Key (not (kindIs "map" $se.legacyV1Key)) -}}{{- $found = true -}}{{- end -}}
{{- if $found -}}true{{- end -}}
{{- end -}}
