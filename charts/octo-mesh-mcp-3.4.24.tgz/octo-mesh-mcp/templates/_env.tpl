{{- define "octo-mesh.system-env" -}}
- name: OCTO_SYSTEM__SYSTEMDATABASENAME
  value: {{ .Values.global.systemDatabaseName }}
- name: OCTO_SYSTEM__DATABASEHOST
  value: {{ .Values.global.clusterDependencies.mongodbHost }}
- name: OCTO_SYSTEM__DATABASEUSERPASSWORD
  valueFrom:
    secretKeyRef:
        name: {{ printf "%s-backend" (include "octo-mesh-mcp.fullname" .) }}
        key: databaseUser
- name: OCTO_SYSTEM__ADMINUSERPASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh-mcp.fullname" .) }}
      key: databaseAdmin
{{- end -}}

{{- define "octo-mesh.broker-env" -}}
- name: {{ printf "%s__BROKERHOST" (upper .name) }}
  value: {{ .global.Values.global.clusterDependencies.rabbitMqHost }}
- name: {{ printf "%s__BROKERUSER" (upper .name) }}
  value: {{ .global.Values.global.clusterDependencies.rabbitMqUser }}
- name: {{ printf "%s__BROKERPASSWORD" (upper .name) }}
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh-mcp.fullname" .global) }}
      key: rabbitmq
{{- end -}}

{{- define "octo-mesh.streamdata-env" -}}
# Instance-level kill switch for StreamData. Read by
# StreamDataInstanceConfiguration (root "StreamData" config section, hence
# the fixed env-var name without a service prefix). Defaults to false so
# the feature is opt-in per cluster.
#
# AB#4232: live since octo-mcp-service 1.5.x — the McpServices Program.cs
# now calls AddCrateDbStreamDataRepository<ConfigureMcpStreamDataConfiguration>()
# which binds OCTO_MCP__STREAMDATAHOST / __USER / __PASSWORD into
# Mcp.StreamData{Host,User,Password} on McpServiceOptions. Pre-1.5.x the
# env vars below landed in the pod but were never read.
- name: OCTO_STREAMDATA__ENABLED
  value: {{ .global.Values.global.clusterDependencies.streamDataEnabled | quote }}
- name: {{ printf "%s__STREAMDATAHOST" (upper .name) }}
  value: {{ .global.Values.global.clusterDependencies.streamDataHost }}
- name: {{ printf "%s__STREAMDATAUSER" (upper .name) }}
  value: {{ .global.Values.global.clusterDependencies.streamDataUser }}
- name: {{ printf "%s__STREAMDATAPASSWORD" (upper .name) }}
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh-mcp.fullname" .global) }}
      key: streamDataPassword
{{- end -}}

{{- define "octo-mesh-mcp.env" -}}
{{- $name := "OCTO_MCP" }}
{{- include "octo-mesh.system-env" . }}
{{ include "octo-mesh.broker-env" (dict "global" . "name" $name) }}
{{ include "octo-mesh.streamdata-env" (dict "global" . "name" $name) }}
- name: OCTO_MCP__AUTHORITYURL
  value: {{ .Values.global.authUri }}
- name: OCTO_MCP__PUBLICURL
  value: {{ .Values.mcp.publicUri }}
- name: OCTO_MCP__INSTANCEPREFIX
  value: {{ .Values.global.instancePrefix }}
{{- /*
Chart 0.10.0 (M2 carry-over): in-cluster URLs for the OctoMesh backend services
the MCP server's SDK-backed tools talk HTTP to (family 1: BlueprintTools,
IdentityTools, AdapterTools, etc.). Without these the tools surface
"Connection refused" or "AssetServiceUrl is not configured" on the first call.
OctoServiceUrls is bound by GetSection("OctoServiceUrls") at root, so the env
var key is OCTO_OCTOSERVICEURLS__<field>, NOT OCTO_MCP__... .
*/}}
{{- if .Values.mcp.octoServiceUrls.asset }}
- name: OCTO_OCTOSERVICEURLS__ASSETSERVICEURL
  value: {{ .Values.mcp.octoServiceUrls.asset | quote }}
{{- end }}
{{- if .Values.mcp.octoServiceUrls.identity }}
- name: OCTO_OCTOSERVICEURLS__IDENTITYSERVICEURL
  value: {{ .Values.mcp.octoServiceUrls.identity | quote }}
{{- end }}
{{- if .Values.mcp.octoServiceUrls.communication }}
- name: OCTO_OCTOSERVICEURLS__COMMUNICATIONSERVICEURL
  value: {{ .Values.mcp.octoServiceUrls.communication | quote }}
{{- end }}
{{- if .Values.mcp.octoServiceUrls.bot }}
- name: OCTO_OCTOSERVICEURLS__BOTSERVICEURL
  value: {{ .Values.mcp.octoServiceUrls.bot | quote }}
{{- end }}
{{- if .Values.mcp.octoServiceUrls.reporting }}
- name: OCTO_OCTOSERVICEURLS__REPORTINGSERVICEURL
  value: {{ .Values.mcp.octoServiceUrls.reporting | quote }}
{{- end }}
{{- if .Values.mcp.octoServiceUrls.adminPanel }}
- name: OCTO_OCTOSERVICEURLS__ADMINPANELURL
  value: {{ .Values.mcp.octoServiceUrls.adminPanel | quote }}
{{- end }}
{{- end -}}
