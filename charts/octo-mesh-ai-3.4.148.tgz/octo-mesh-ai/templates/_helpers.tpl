{{/*
Expand the name of the chart.
*/}}
{{- define "octo-mesh-ai.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "octo-mesh-ai.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "octo-mesh-ai.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "octo-mesh-ai.labels" -}}
helm.sh/chart: {{ include "octo-mesh-ai.chart" . }}
{{ include "octo-mesh-ai.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "octo-mesh-ai.selectorLabels" -}}
app.kubernetes.io/name: {{ include "octo-mesh-ai.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "octo-mesh-ai.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "octo-mesh-ai.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Check if a mandatory value exists
*/}}
{{- define "checkMandatoryValue" -}}
{{- if not .value -}}
{{- fail (printf "Value %s does not exist. Please define a corresponding value." .name) -}}
{{- end -}}
{{- end -}}

{{/*
Per-tenant worker object name. Truncated at 63 chars to fit DNS label limits.
Expects: dict "root" $ "tenant" $tenant — `root` is the chart context so the
helper can use the standard fullname; `tenant` is the entry from
.Values.worker.tenants.
*/}}
{{- define "octo-mesh-ai.workerFullname" -}}
{{- $root := .root -}}
{{- $tenant := .tenant -}}
{{- printf "%s-worker-%s" (include "octo-mesh-ai.fullname" $root) $tenant.id | trunc 63 | trimSuffix "-" }}
{{- end -}}

{{/*
M5 §2 — per-tenant worker ServiceAccount name (chart 0.21.0).

When `worker.perTenantServiceAccount.enabled=true` each worker
Deployment binds to a dedicated SA `<release>-worker-<tenantId>`-sa so
cluster RBAC can be scoped per tenant (no shared identity even if
`automountServiceAccountToken` ever flips on). When disabled, fallback
to the chart-wide `octo-mesh-ai.serviceAccountName` so the pre-M5
behaviour is preserved bit-for-bit.

Expects: dict "root" $ "tenant" $tenant
*/}}
{{- define "octo-mesh-ai.workerServiceAccountName" -}}
{{- $root := .root -}}
{{- $tenant := .tenant -}}
{{- if $root.Values.worker.perTenantServiceAccount.enabled -}}
{{- printf "%s-sa" (include "octo-mesh-ai.workerFullname" (dict "root" $root "tenant" $tenant)) | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- include "octo-mesh-ai.serviceAccountName" $root -}}
{{- end -}}
{{- end -}}

{{/*
Per-tenant Tailscale hostname. Falls back to the chart-level pattern with
`{tenant}` substituted.
*/}}
{{- define "octo-mesh-ai.workerTailscaleHostname" -}}
{{- $root := .root -}}
{{- $tenant := .tenant -}}
{{- if $tenant.tailscaleHostname -}}
{{- $tenant.tailscaleHostname }}
{{- else -}}
{{- $root.Values.worker.tailscale.hostnamePattern | replace "{tenant}" $tenant.id }}
{{- end -}}
{{- end -}}

{{/*
SECRET attribute key ring (AB#5536, concept AB#5528 §3.5, decision 3).
Mirrors "octo-mesh.secretEncryption" in octo-helm-core/src/octo-mesh — keep the
two in step.

Call with (dict "secrets" <secrets map> "path" "<values path for messages>"
"fallbackInstanceKey" <optional>) and read the result with fromJson:
  { "keys": {kid: base64Key}, "activeKeyId": "k1", "legacyV1Key": base64Key }

Default (no override map): the instance secret (communicationInstanceSecretKey,
the same value the octo-mesh chart carries) IS key `k1` and the legacy `enc:v1`
key, and `k1` is active. No new required value: without an instance secret the
ring is empty and the chart emits nothing — the service starts and only SECRET
attribute access fails with a configuration error.

Rotation override: a non-empty secretEncryptionKeys REPLACES the derived ring
(list k1 again while it is still needed) and secretEncryptionActiveKeyId picks
the active key. LegacyV1Key always stays the instance secret.

Key ids: 1-32 lowercase letters/digits — the id is part of an env var name, a
Secret key and the `enc:v2:<kid>:` header, and keeps its case in the env var.
*/}}
{{- define "octo-mesh.secretEncryption" -}}
{{- $s := .secrets | default dict -}}
{{- $path := .path -}}
{{- $instanceKey := $s.communicationInstanceSecretKey | default .fallbackInstanceKey | default "" -}}
{{- $keys := dict -}}
{{- $override := $s.secretEncryptionKeys | default dict -}}
{{- if $override -}}
{{- range $kid, $value := $override -}}
{{- if not (regexMatch "^[a-z0-9]{1,32}$" $kid) -}}
{{- fail (printf "%s.secretEncryptionKeys: key id '%s' must be 1-32 lowercase letters or digits" $path $kid) -}}
{{- end -}}
{{- if not $value -}}
{{- fail (printf "%s.secretEncryptionKeys.%s is empty; remove the entry instead" $path $kid) -}}
{{- end -}}
{{- if ne (len (b64dec $value)) 32 -}}
{{- fail (printf "%s.secretEncryptionKeys.%s must be a base64-encoded 32-byte key (openssl rand -base64 32)" $path $kid) -}}
{{- end -}}
{{- $_ := set $keys $kid $value -}}
{{- end -}}
{{- else if $instanceKey -}}
{{- $_ := set $keys "k1" $instanceKey -}}
{{- end -}}
{{- $active := "" -}}
{{- if $keys -}}
{{- $active = $s.secretEncryptionActiveKeyId | default "k1" -}}
{{- if not (hasKey $keys $active) -}}
{{- fail (printf "%s.secretEncryptionActiveKeyId '%s' is not a key id of the SECRET key ring (%s)" $path $active (keys $keys | sortAlpha | join ", ")) -}}
{{- end -}}
{{- end -}}
{{- toJson (dict "keys" $keys "activeKeyId" $active "legacyV1Key" $instanceKey) -}}
{{- end -}}

{{/*
Env block for the SECRET key ring (AB#5536), bound by the engine in
AddRuntimeEngine() as SecretEncryption:Keys:<kid> / :ActiveKeyId / :LegacyV1Key.
Call with (dict "ring" <ring dict> "secretName" "<release>-backend").
*/}}
{{- define "octo-mesh.secretEncryption-env" -}}
{{- $secretName := .secretName }}
{{- range $kid, $_ := .ring.keys }}
- name: OCTO_SECRETENCRYPTION__KEYS__{{ $kid }}
  valueFrom:
    secretKeyRef:
      name: {{ $secretName }}
      key: {{ printf "secretEncryptionKey-%s" $kid }}
{{- end }}
{{- if .ring.keys }}
- name: OCTO_SECRETENCRYPTION__ACTIVEKEYID
  value: {{ .ring.activeKeyId | quote }}
{{- end }}
{{- if .ring.legacyV1Key }}
- name: OCTO_SECRETENCRYPTION__LEGACYV1KEY
  valueFrom:
    secretKeyRef:
      name: {{ $secretName }}
      key: communicationInstanceSecretKey
{{- end }}
{{- end -}}

{{/*
Effective SECRET key ring of this chart (AB#5536), as JSON. The instance secret
is global.secrets.communicationInstanceSecretKey; when that is empty it falls
back to global.secrets.aiInstanceSecretKey, which this chart already documents
as byte-identical to the octo-mesh communicationInstanceSecretKey — so clusters
that only set aiInstanceSecretKey get the ring without a new value.
*/}}
{{- define "octo-mesh-ai.secretEncryptionRing" -}}
{{- include "octo-mesh.secretEncryption" (dict "secrets" .Values.global.secrets "path" "global.secrets" "fallbackInstanceKey" .Values.global.secrets.aiInstanceSecretKey) -}}
{{- end -}}
