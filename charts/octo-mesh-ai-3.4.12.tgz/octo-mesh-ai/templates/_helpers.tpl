{{/*
Expand the name of the chart.
*/}}
{{- define "octo-mesh-ai.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "octo-mesh-ai.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "octo-mesh-ai.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "octo-mesh-ai.labels" -}}
helm.sh/chart: {{ include "octo-mesh-ai.chart" . }}
{{ include "octo-mesh-ai.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "octo-mesh-ai.selectorLabels" -}}
app.kubernetes.io/name: {{ include "octo-mesh-ai.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "octo-mesh-ai.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "octo-mesh-ai.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Check if a mandatory value exists
*/}}
{{- define "checkMandatoryValue" -}}
{{- if not .value -}}
{{- fail (printf "Value %s does not exist. Please define a corresponding value." .name) -}}
{{- end -}}
{{- end -}}

{{/*
Per-tenant worker object name. Truncated at 63 chars to fit DNS label limits.
Expects: dict "root" $ "tenant" $tenant — `root` is the chart context so the
helper can use the standard fullname; `tenant` is the entry from
.Values.worker.tenants.
*/}}
{{- define "octo-mesh-ai.workerFullname" -}}
{{- $root := .root -}}
{{- $tenant := .tenant -}}
{{- printf "%s-worker-%s" (include "octo-mesh-ai.fullname" $root) $tenant.id | trunc 63 | trimSuffix "-" }}
{{- end -}}

{{/*
M5 §2 — per-tenant worker ServiceAccount name (chart 0.21.0).

When `worker.perTenantServiceAccount.enabled=true` each worker
Deployment binds to a dedicated SA `<release>-worker-<tenantId>`-sa so
cluster RBAC can be scoped per tenant (no shared identity even if
`automountServiceAccountToken` ever flips on). When disabled, fallback
to the chart-wide `octo-mesh-ai.serviceAccountName` so the pre-M5
behaviour is preserved bit-for-bit.

Expects: dict "root" $ "tenant" $tenant
*/}}
{{- define "octo-mesh-ai.workerServiceAccountName" -}}
{{- $root := .root -}}
{{- $tenant := .tenant -}}
{{- if $root.Values.worker.perTenantServiceAccount.enabled -}}
{{- printf "%s-sa" (include "octo-mesh-ai.workerFullname" (dict "root" $root "tenant" $tenant)) | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- include "octo-mesh-ai.serviceAccountName" $root -}}
{{- end -}}
{{- end -}}

{{/*
Per-tenant Tailscale hostname. Falls back to the chart-level pattern with
`{tenant}` substituted.
*/}}
{{- define "octo-mesh-ai.workerTailscaleHostname" -}}
{{- $root := .root -}}
{{- $tenant := .tenant -}}
{{- if $tenant.tailscaleHostname -}}
{{- $tenant.tailscaleHostname }}
{{- else -}}
{{- $root.Values.worker.tailscale.hostnamePattern | replace "{tenant}" $tenant.id }}
{{- end -}}
{{- end -}}
