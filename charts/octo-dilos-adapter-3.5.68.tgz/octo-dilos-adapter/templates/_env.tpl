{{/*
  Kubernetes EnvVar.value is typed string, so every env value must render as a
  YAML string scalar. Without `| quote`, values that look like YAML scalars of
  another type (numbers, booleans, "null", "yes/no") get interpreted as that
  type and the apiserver rejects the Deployment with
  "cannot unmarshal number into Go struct field EnvVar.value of type string".
  Specifically: blueprint-seeded RtIds like 670000000000000000000002 are 24
  decimal digits and parse as numbers. `| quote` everywhere — env values are
  always strings.
*/}}
{{- define "octo-mesh.system-env" -}}
- name: OCTO_SYSTEM__DATABASEHOST
  value: {{ .Values.clusterDependencies.mongodbHost | quote }}
{{- if .Values.clusterDependencies.systemDatabaseName }}
{{/*
  Instance isolation (Epic AB#4944): the tenant registry lives in this database, and
  the adapter resolves its own tenant through it on every CK-model load. It must match
  the core services' serviceDefaults.systemDatabaseName; an instance on a non-default
  system database otherwise fails with "Tenant '<id>' does not exist". Omitted when
  unset, so a single-instance cluster keeps the adapter's compiled-in default.
*/}}
- name: OCTO_SYSTEM__SYSTEMDATABASENAME
  value: {{ .Values.clusterDependencies.systemDatabaseName | quote }}
{{- end }}
{{- if .Values.clusterDependencies.mongodbReplicaSet }}
- name: OCTO_SYSTEM__REPLICASETNAME
  value: {{ .Values.clusterDependencies.mongodbReplicaSet | quote }}
{{- end }}
{{ include "octo-mesh.secretEnv" (dict "envName" "OCTO_SYSTEM__DATABASEUSERPASSWORD" "value" .Values.secrets.databaseUser "legacyKey" "databaseUser" "context" .) }}
{{ include "octo-mesh.secretEnv" (dict "envName" "OCTO_SYSTEM__ADMINUSERPASSWORD" "value" .Values.secrets.databaseAdmin "legacyKey" "databaseAdmin" "context" .) }}
{{- end }}

{{- define "octo-mesh.broker-env" -}}
- name: {{ printf "%s__BROKERHOST" (upper .name) }}
  value: {{ .global.Values.clusterDependencies.rabbitMqHost | quote }}
- name: {{ printf "%s__BROKERUSERNAME" (upper .name) }}
  value: {{ .global.Values.clusterDependencies.rabbitMqUser | quote }}
{{ include "octo-mesh.secretEnv" (dict "envName" (printf "%s__BROKERPASSWORD" (upper .name)) "value" .global.Values.secrets.rabbitmq "legacyKey" "rabbitmq" "context" .global) }}
{{- end }}

{{- define "octo-mesh.streamdata-env" -}}
# Instance-level kill switch for StreamData. Read by
# StreamDataInstanceConfiguration (root "StreamData" config section, hence
# the fixed env-var name without a service prefix). Defaults to false so
# the feature is opt-in per cluster.
- name: OCTO_STREAMDATA__ENABLED
  value: {{ .global.Values.clusterDependencies.streamDataEnabled | quote }}
{{- if .global.Values.clusterDependencies.streamDataSchemaInstancePrefix }}
{{/*
  AB#4946 / Epic AB#4944: prefixes the tenant's CrateDB schema so a second instance
  does not read and write the first one's data. Same root "StreamData" config section
  as the kill switch above, hence no service prefix. Omitted when unset — the legacy,
  unprefixed schema names stay byte-identical.
*/}}
- name: OCTO_STREAMDATA__SCHEMAINSTANCEPREFIX
  value: {{ .global.Values.clusterDependencies.streamDataSchemaInstancePrefix | quote }}
{{- end }}
- name: {{ printf "%s__STREAMDATAHOST" (upper .name) }}
  value: {{ .global.Values.clusterDependencies.streamDataHost | quote }}
- name: {{ printf "%s__STREAMDATAUSER" (upper .name) }}
  value: {{ .global.Values.clusterDependencies.streamDataUser | quote }}
{{ include "octo-mesh.secretEnv" (dict "envName" (printf "%s__STREAMDATAPASSWORD" (upper .name)) "value" .global.Values.secrets.streamDataPassword "legacyKey" "streamDataPassword" "context" .global) }}
{{- end }}


{{- define "octo-mesh.env" -}}
- name: ASPNETCORE_URLS
  value: "http://+:80"
{{- /*
  AB#5478 §2.1 + §2.2, as in the product's octo-mesh-adapter chart (main 1263a0a): the
  workload's own identity in Dash0. OTEL_SERVICE_NAME is the release name, under the operator
  {tenantId}-{workloadName} and already the app.kubernetes.io/service label, so metrics, traces
  and logs land on the same name; octo.tenant.id carries the tenant as its own dimension.
  Guarded on tenantId because an empty value would publish `octo.tenant.id=` as a real, wrong
  attribute.
*/}}
- name: OTEL_SERVICE_NAME
  value: {{ include "octo-mesh.service-fullname" . | quote }}
{{- if .Values.tenantId }}
- name: OTEL_RESOURCE_ATTRIBUTES
  value: {{ printf "octo.tenant.id=%s" .Values.tenantId | quote }}
{{- end }}
# The SDK's own ActivitySources, declared to the injected .NET auto-instrumentation; the host
# carries the product's mesh-adapter nodes and with them the StreamData engine. Same list as the
# product chart; keep the two in step.
- name: OTEL_DOTNET_AUTO_TRACES_ADDITIONAL_SOURCES
  value: "Meshmakers.Octo.StreamData,Meshmakers.Octo.StreamData.Crate"
{{- /*
  AB#5478 section 2.3: nlog.config reads OCTO_LOG_LEVEL (Meshmakers.*) and OCTO_LOG_LEVEL_ROOT
  (everything else), both Info when unset. Omitted unless set.
*/}}
{{- if .Values.logLevel }}
- name: OCTO_LOG_LEVEL
  value: {{ .Values.logLevel | quote }}
{{- end }}
{{- if .Values.logLevelRoot }}
- name: OCTO_LOG_LEVEL_ROOT
  value: {{ .Values.logLevelRoot | quote }}
{{- end }}
{{- $name := "OCTO_ADAPTER" }}
{{ include "octo-mesh.system-env" . }}
{{ include "octo-mesh.broker-env" (dict "global" . "name" $name) }}
{{ include "octo-mesh.streamdata-env" (dict "global" . "name" $name) }}
- name: OCTO_ADAPTER__INSTANCEPREFIX
  value: {{ .Values.instancePrefix | quote }}
{{- /*
  AB#4924 increment 3: the SDK binds the old OCTO_ADAPTER__TENANTID only for one deprecation
  release (ConfigureLegacyAdapterTenantId, with a warning on every start); without either key the
  adapter falls back to the "meshTest" default and connects on the wrong tenant route.
  DEDICATEDTENANTID is the key the product chart renders: the single tenant this adapter is
  pinned to, for its hub route and its own credential.
*/}}
- name: OCTO_ADAPTER__DEDICATEDTENANTID
  value: {{ .Values.tenantId | quote }}
- name: OCTO_ADAPTER__COMMUNICATIONCONTROLLERSERVICESURI
  value: {{ .Values.communicationControllerServiceUri | quote }}
{{- if .Values.ignoreCertificateValidation }}
{{/*
  AB#5303 items 1+2, as in the product chart. Rendered ONLY when set, never `false`: an absent
  variable and a false one mean the same to the SDK, and an absent one cannot be mistaken for a
  deliberate choice. It turns off TLS certificate validation for every outgoing Octo call of the
  process, and the SDK refuses it when ASPNETCORE_ENVIRONMENT says Production. Development and
  private-PKI clusters only; the operator projects it when the cluster asks for it.
*/}}
- name: OCTO_ADAPTER__IGNORECERTIFICATEVALIDATION
  value: "true"
{{- end }}
- name: OCTO_ADAPTER__ADAPTERCKTYPEID
  value: "System.Communication/Adapter"
- name: OCTO_ADAPTER__ADAPTERRTID
  value: {{ .Values.adapterRtId | quote }}
- name: OCTO_ADAPTER__REPORTINGSERVICEURL
  value: {{ .Values.reportingServiceUri | quote }}
{{/*
  AB#5072 / AB#6669 -- ONE chart value, TWO opposite directions.

  AUTHORITYURL is INBOUND: the issuer that secured FromHttpRequest@2 routes accept
  on tokens presented TO this adapter. It lives on MeshAdapterConfiguration, which
  Program.cs configures (Octo.Sdk.MeshAdapter, shared by every mesh-node adapter,
  this one included) and ConfigureJwtBearerOptions reads. Without it the compiled-in
  default stays https://localhost:5003; outside Development that is loopback, so the
  adapter logs "Adapter:AuthorityUrl ... JWT bearer authentication is therefore
  disabled" at startup and every caller of a secured route is denied with HTTP 401.
  The weclapp chart this one descends from used to omit it on the (outdated)
  assumption that the adapter has no MeshAdapterConfiguration; it has (AB#6669).

  ISSUERURI is OUTBOUND: the identity the adapter presents when it connects to
  /{tenantId}/adapterHub. Read by AdapterOptions in octo-communication-sdk, which
  every SDK-based adapter shares, so that key is deliberately byte-identical
  across the adapter charts.

  Both are fed from the SAME `authUri` on purpose -- one identity service issues
  and validates both directions, so a second chart value could only ever drift.
  Same block as the octo-mesh-adapter and octo-eda-adapter charts.

  `authUri` needs no new plumbing: the communication operator writes it into the
  context values of EVERY workload (WorkloadContextValuesBuilder). It must be the
  PUBLIC issuer address -- OIDC discovery runs against it in both directions, and
  the communication controller validates the issuer of the resulting token.
*/}}
{{- if .Values.authUri }}
- name: OCTO_ADAPTER__AUTHORITYURL
  value: {{ .Values.authUri | quote }}
- name: OCTO_ADAPTER__ISSUERURI
  value: {{ .Values.authUri | quote }}
{{- end }}
{{/*
  Client id of the adapter's own confidential OAuth client -- the
  ServiceAccountConfiguration the communication controller provisions per adapter
  (AB#5027) and projects onto this exact path as a ValueOverride at deploy time.
  Omitted when unset: AdapterOptions.IsEnabled is `IssuerUri && ClientId`, so an
  unconfigured adapter acquires no token and connects anonymously -- which is what
  the whole fleet does today and must keep doing on upgrade.
*/}}
{{- if .Values.serviceAccountClientId }}
- name: OCTO_ADAPTER__CLIENTID
  value: {{ .Values.serviceAccountClientId | quote }}
{{- end }}
{{/*
  🔴 Secret-flagged on the controller side, so the operator materialises it into
  {release}-octo-secrets and hands this path a {valueFrom: {secretKeyRef: ...}} map
  instead of the plaintext -- octo-mesh.secretEnv accepts both shapes, exactly as
  secrets.rabbitmq does. Guarded by `if` because secretEnv FAILS on an empty value
  (deliberate for the four mandatory cluster secrets) while this one is optional by
  design -- see the ClientId note above.
*/}}
{{- if .Values.secrets.serviceAccountClientSecret }}
{{ include "octo-mesh.secretEnv" (dict "envName" "OCTO_ADAPTER__CLIENTSECRET" "value" .Values.secrets.serviceAccountClientSecret "legacyKey" "serviceAccountClientSecret" "context" .) }}
{{- end }}
{{- end }}
