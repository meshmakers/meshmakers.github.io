#!/usr/bin/env bash
# Render tests of the LLM gateway settings of the octo-mesh-ai chart (AB#9728, per-tenant values retired by AB#8690): ai.llmGateway.* ->
# OCTO_LLMGATEWAY__* on the AI service, the central key only through the backend Secret, fail closed without values.
# Needs only `helm` (no cluster). Run: bash src/octo-mesh-ai/tests/llm-gateway-render-tests.sh
set -u
CHART="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$(cd "$CHART/.." && pwd)"
SAMPLE="$SRC/examples/ai-sample.yaml"
FAILED=0
# A recognisable fake key: it must never appear in clear text in a rendered manifest.
KEY="fake-central-key-ab9728"
KEY_B64="$(printf '%s' "$KEY" | base64)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

check() { local name="$1"; shift; if "$@"; then echo "ok   - $name"; else echo "FAIL - $name"; FAILED=1; fi; }
renders_fail() {
  local name="$1" expected="$2"; shift 2
  local out; if out="$("$@" 2>&1)"; then echo "FAIL - $name (render succeeded)"; FAILED=1; return; fi
  check "$name" grep -qF "$expected" <<<"$out"
}
render() { helm template t "$CHART" --values "$SAMPLE" "$@" 2>&1; }
# The output is a rendered manifest, not an error (absence checks are vacuous on a failed render).
rendered() { grep -q 'name: OCTO_AI__AUTHORITYURL' <<<"$1"; }
# Value of the env variable $2 in rendered output $1 (first match).
envval() { grep -A1 "name: $2\$" <<<"$1" | sed -n 's/^ *value: //p' | head -n1; }
count() { grep -c -- "$2" <<<"$1"; }

# The opened configuration as a values file, so numbers arrive as YAML numbers, not strings.
cat >"$TMP/open.yaml" <<EOF
ai:
  llmGateway:
    enabled: true
    anthropicApiKey: "$KEY"
    usdToEurRate: 0.93
EOF
OPEN=(--values "$TMP/open.yaml")

# ---- fail closed ----
OUT="$(render)"
check "default: renders (test is not vacuous)"                       grep -q 'name: OCTO_AI__AUTHORITYURL' <<<"$OUT"
check "default: no OCTO_LLMGATEWAY__ variable"                       test "$(count "$OUT" 'OCTO_LLMGATEWAY__')" = 0
check "default: no gateway key in the Secret"                        test "$(count "$OUT" 'aiLlmGatewayAnthropicApiKey')" = 0

OUT="$(render "${OPEN[@]}" --set ai.llmGateway.enabled=false)"
check "enabled=false with all values set: renders"          rendered "$OUT"
check "enabled=false with all values set: no OCTO_LLMGATEWAY__ variable" test "$(count "$OUT" 'OCTO_LLMGATEWAY__')" = 0
check "enabled=false with all values set: no gateway key in the Secret"  test "$(count "$OUT" 'aiLlmGatewayAnthropicApiKey')" = 0
check "enabled=false: key nowhere in the output"                     test "$(count "$OUT" "$KEY_B64")" = 0

# ---- opened ----
OUT="$(render "${OPEN[@]}")"
check "open: key variable present once"                              test "$(count "$OUT" 'name: OCTO_LLMGATEWAY__ANTHROPICAPIKEY$')" = 1
KEYREF="$(grep -A4 'name: OCTO_LLMGATEWAY__ANTHROPICAPIKEY$' <<<"$OUT")"
check "open: key comes from the backend Secret"                      grep -q 'name: t-octo-mesh-ai-backend' <<<"$KEYREF"
check "open: key comes from the gateway key of that Secret"          grep -q 'key: aiLlmGatewayAnthropicApiKey' <<<"$KEYREF"
check "open: key variable has no plain value"                        test -z "$(envval "$OUT" OCTO_LLMGATEWAY__ANTHROPICAPIKEY)"
check "open: Secret carries the key base64-encoded"                  grep -qF "aiLlmGatewayAnthropicApiKey: \"$KEY_B64\"" <<<"$OUT"
check "open: key never in clear text"                                test "$(count "$OUT" "$KEY")" = 0
check "open: rate rendered from a YAML number"                       test "$(envval "$OUT" OCTO_LLMGATEWAY__USDTOEURRATE)" = '"0.93"'
check "open: exactly 2 gateway variables (no per-tenant keys)"      test "$(count "$OUT" 'name: OCTO_LLMGATEWAY__')" = 2
check "open: no retired per-tenant variable"                         test "$(count "$OUT" 'OCTO_LLMGATEWAY__TENANTS__')" = 0
check "open: chart passes no provider URL"                           test "$(count "$OUT" 'ANTHROPICBASEURL')" = 0

OUT="$(render "${OPEN[@]}" --set ai.llmGateway.usdToEurRate=1)"
check "string forms: rate 1"                                         test "$(envval "$OUT" OCTO_LLMGATEWAY__USDTOEURRATE)" = '"1"'

# The per-tenant workers run Claude Code, not the gateway: they must not get the central key.
OUT="$(render "${OPEN[@]}" --set worker.enabled=true --set 'worker.tenants[0].id=acme')"
check "worker: two Deployments rendered (test is not vacuous)"       test "$(grep -c '^kind: Deployment' <<<"$OUT")" = 2
check "worker: only the ai deployment carries the key variable"      test "$(count "$OUT" 'name: OCTO_LLMGATEWAY__ANTHROPICAPIKEY$')" = 1
check "worker: only one secretKeyRef to the gateway key"             test "$(count "$OUT" 'key: aiLlmGatewayAnthropicApiKey')" = 1

# ---- invalid configuration fails the render ----
G=ai.llmGateway
renders_fail "no key"                     "needs ai.llmGateway.anthropicApiKey"      render "${OPEN[@]}" --set "$G.anthropicApiKey="
renders_fail "no rate"                    "usdToEurRate must be a positive decimal number, got ''" render "${OPEN[@]}" --set "$G.usdToEurRate="
renders_fail "rate zero"                  "usdToEurRate must be a positive decimal number, got '0'" render "${OPEN[@]}" --set "$G.usdToEurRate=0"
renders_fail "rate 0.0"                   "usdToEurRate must be a positive decimal number, got '0.0'" render "${OPEN[@]}" --set-string "$G.usdToEurRate=0.0"
renders_fail "rate negative"              "usdToEurRate must be a positive decimal number, got '-1'" render "${OPEN[@]}" --set "$G.usdToEurRate=-1"
renders_fail "rate text"                  "usdToEurRate must be a positive decimal number, got 'abc'" render "${OPEN[@]}" --set "$G.usdToEurRate=abc"
renders_fail "rate with comma"            "usdToEurRate must be a positive decimal number, got '0,93'" render "${OPEN[@]}" --set-string "$G.usdToEurRate=0\,93"
# AB#8690: per-tenant values are retired; key source and cap come from octo-cli SetAiSpendCap.
renders_fail "retired tenants value"      "ai.llmGateway.tenants is retired (AB#8690)" render "${OPEN[@]}" --set "$G.tenants.acme.keySource=CentralKey" --set "$G.tenants.acme.capMonthlyEur=20"
renders_fail "retired tenants not a map"  "ai.llmGateway.tenants is retired (AB#8690)" render "${OPEN[@]}" --set-json "$G.tenants=[\"acme\"]"
OUT="$(render "${OPEN[@]}" --set-json "$G.tenants={}")"
check "empty tenants map is accepted"                                test "$(count "$OUT" 'name: OCTO_LLMGATEWAY__USDTOEURRATE$')" = 1
OUT="$(render "${OPEN[@]}" --set ai.llmGateway.enabled=false --set "$G.tenants.acme.keySource=CentralKey")"
check "enabled=false ignores a leftover tenants value: renders"          rendered "$OUT"
check "enabled=false ignores a leftover tenants value"               test "$(count "$OUT" 'OCTO_LLMGATEWAY__')" = 0

# ---- flags must be booleans: a string "false" must not open the gateway ----
renders_fail "enabled as string"          "ai.llmGateway.enabled must be true or false" render "${OPEN[@]}" --set-string "$G.enabled=false"
renders_fail "recon enabled as string"    "ai.llmGateway.reconciliation.enabled must be true or false" render "${OPEN[@]}" --set-string "$G.reconciliation.enabled=false"

# ---- AB#8694: daily reconciliation ----
ADMIN="fake-admin-key-ab8694"
ADMIN_B64="$(printf '%s' "$ADMIN" | base64)"
R=ai.llmGateway.reconciliation
RECON=(--set "$R.enabled=true" --set "$R.anthropicAdminApiKey=$ADMIN" --set "$R.workspaceId=wrkspc_01Central")
OUT="$(render "${OPEN[@]}")"
check "recon default: renders"          rendered "$OUT"
check "recon default: no reconciliation variable"                   test "$(count "$OUT" 'OCTO_LLMGATEWAY__RECONCILIATION__')" = 0
check "recon default: no Admin key in the Secret"                    test "$(count "$OUT" 'aiLlmGatewayAnthropicAdminApiKey')" = 0
OUT="$(render "${OPEN[@]}" "${RECON[@]}")"
check "recon: enabled variable"                                      test "$(envval "$OUT" OCTO_LLMGATEWAY__RECONCILIATION__ENABLED)" = '"true"'
check "recon: workspace id"                                          test "$(envval "$OUT" OCTO_LLMGATEWAY__RECONCILIATION__WORKSPACEID)" = '"wrkspc_01Central"'
ADMINREF="$(grep -A4 'name: OCTO_LLMGATEWAY__RECONCILIATION__ANTHROPICADMINAPIKEY$' <<<"$OUT")"
check "recon: Admin key from the backend Secret"                     grep -q 'name: t-octo-mesh-ai-backend' <<<"$ADMINREF"
check "recon: Admin key from its own Secret key"                     grep -q 'key: aiLlmGatewayAnthropicAdminApiKey' <<<"$ADMINREF"
check "recon: Admin key variable has no plain value"                 test -z "$(envval "$OUT" OCTO_LLMGATEWAY__RECONCILIATION__ANTHROPICADMINAPIKEY)"
check "recon: Secret carries the Admin key base64-encoded"           grep -qF "aiLlmGatewayAnthropicAdminApiKey: \"$ADMIN_B64\"" <<<"$OUT"
check "recon: Admin key never in clear text"                         test "$(count "$OUT" "$ADMIN")" = 0
check "recon: chart passes no Admin API URL"                         test "$(count "$OUT" 'ADMINAPIBASEURL')" = 0
OUT="$(render "${OPEN[@]}" "${RECON[@]}" --set worker.enabled=true --set 'worker.tenants[0].id=acme')"
check "recon worker: only the ai deployment carries the Admin key"   test "$(count "$OUT" 'key: aiLlmGatewayAnthropicAdminApiKey')" = 1
renders_fail "recon: no Admin key"        "needs ai.llmGateway.reconciliation.anthropicAdminApiKey" render "${OPEN[@]}" "${RECON[@]}" --set "$R.anthropicAdminApiKey="
renders_fail "recon: no workspace"        "workspaceId must be the id of the central workspace (wrkspc_...), got ''" render "${OPEN[@]}" "${RECON[@]}" --set "$R.workspaceId="
renders_fail "recon: bad workspace"       "got 'default'" render "${OPEN[@]}" "${RECON[@]}" --set "$R.workspaceId=default"
renders_fail "recon: gateway off"         "needs ai.llmGateway.enabled=true" render "${RECON[@]}"
OUT="$(render "${OPEN[@]}" --set "$R.enabled=false" --set "$R.anthropicAdminApiKey=$ADMIN")"
check "recon off: renders"          rendered "$OUT"
check "recon off: Admin key nowhere in the output"                   test "$(count "$OUT" "$ADMIN_B64")" = 0

exit $FAILED
