{{- define "octo-mesh.system-env" -}}
- name: OCTO_SYSTEM__SYSTEMDATABASENAME
  value: {{ .Values.global.systemDatabaseName }}
- name: OCTO_SYSTEM__DATABASEHOST
  value: {{ .Values.global.clusterDependencies.mongodbHost }}
- name: OCTO_SYSTEM__DATABASEUSERPASSWORD
  valueFrom:
    secretKeyRef:
        name: {{ printf "%s-backend" (include "octo-mesh-ai.fullname" .) }}
        key: databaseUser
- name: OCTO_SYSTEM__ADMINUSERPASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh-ai.fullname" .) }}
      key: databaseAdmin
{{- /*
SECRET attribute key ring (AB#5536): part of system-env because this service
hosts the runtime engine (AddRuntimeEngine binds SecretEncryption:*). Same block
as octo-helm-core/src/octo-mesh/templates/_env.tpl.
*/}}
{{- include "octo-mesh.secretEncryption-env" (dict "ring" (fromJson (include "octo-mesh-ai.secretEncryptionRing" .)) "secretName" (printf "%s-backend" (include "octo-mesh-ai.fullname" .))) }}
{{- end -}}

{{- define "octo-mesh.broker-env" -}}
- name: {{ printf "%s__BROKERHOST" (upper .name) }}
  value: {{ .global.Values.global.clusterDependencies.rabbitMqHost }}
- name: {{ printf "%s__BROKERUSER" (upper .name) }}
  value: {{ .global.Values.global.clusterDependencies.rabbitMqUser }}
- name: {{ printf "%s__BROKERPASSWORD" (upper .name) }}
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh-ai.fullname" .global) }}
      key: rabbitmq
{{- end -}}

{{- define "octo-mesh.streamdata-env" -}}
# Instance-level kill switch for StreamData. Read by
# StreamDataInstanceConfiguration (root "StreamData" config section, hence
# the fixed env-var name without a service prefix). Defaults to false so
# the feature is opt-in per cluster.
- name: OCTO_STREAMDATA__ENABLED
  value: {{ .global.Values.global.clusterDependencies.streamDataEnabled | quote }}
- name: {{ printf "%s__STREAMDATAHOST" (upper .name) }}
  value: {{ .global.Values.global.clusterDependencies.streamDataHost }}
- name: {{ printf "%s__STREAMDATAUSER" (upper .name) }}
  value: {{ .global.Values.global.clusterDependencies.streamDataUser }}
- name: {{ printf "%s__STREAMDATAPASSWORD" (upper .name) }}
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh-ai.fullname" .global) }}
      key: streamDataPassword
{{- end -}}

{{- define "octo-mesh-ai.env" -}}
{{- $name := "OCTO_AI" }}
{{- /*
  AB#5478 §2.1 — one service.name per process. The pod label
  app.kubernetes.io/name is already the chart name here, so traces and logs were
  right; the in-process SDK fell back to the entry assembly name without
  OTEL_SERVICE_NAME, which put this service's custom metrics into a separate Dash0
  entity (Meshmakers.Octo.Backend.AiServices) from its own spans. Value matches the
  label on purpose. Same block as in the mcp and reporting charts.

  Note the per-tenant worker Deployment sets its own value (…-worker) — it shares
  this chart's label but is a different process, and collapsing the two would hide
  worker latency inside the service's own numbers.
*/}}
- name: OTEL_SERVICE_NAME
  value: {{ include "octo-mesh-ai.name" . | quote }}
{{- /*
  Our own ActivitySources, declared to the injected auto-instrumentation: this
  service hosts the StreamData engine and the in-process TracerProvider carries no
  exporter by design. Mirrors octo-helm-core/src/octo-mesh/templates/_env.tpl.
*/}}
- name: OTEL_DOTNET_AUTO_TRACES_ADDITIONAL_SOURCES
  value: "Meshmakers.Octo.StreamData,Meshmakers.Octo.StreamData.Crate"
{{ include "octo-mesh.system-env" . }}
{{ include "octo-mesh.broker-env" (dict "global" . "name" $name) }}
{{ include "octo-mesh.streamdata-env" (dict "global" . "name" $name) }}
- name: OCTO_AI__AUTHORITYURL
  value: {{ .Values.global.authUri }}
- name: OCTO_AI__ASSETSERVICESURL
  value: {{ .Values.global.assetRepositoryUri }}
- name: OCTO_AI__PUBLICURL
  value: {{ .Values.ai.publicUri }}
{{- include "octo-mesh-pro.tenant-generation-enforcement-env" . }}
{{- /*
Chart 0.20.0 (B-2e carry-over): the Anthropic API key lives in the
`{release}-backend` Secret instead of riding as a plain-text env var.
The old shape leaked through `kubectl get pod -o jsonpath` during
routine diagnostics; valueFrom.secretKeyRef keeps it out of every
read-only pod inspection path. Same pattern aiMcpAuthClientId already
uses.
*/}}
- name: OCTO_AI__AnthropicApiKey
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh-ai.fullname" .) }}
      key: aiAnthropicApiKey
{{- include "octo-mesh-ai.llmGateway-env" . }}
- name: OCTO_AI__AnthropicModel
  value: {{ .Values.ai.anthropic.anthropicModel }}
- name: OCTO_AI__MaxTokens
  value: {{ .Values.ai.anthropic.maxTokens | quote }}
- name: OCTO_AI__Temperature
  value: {{ .Values.ai.anthropic.temperature | quote }}
- name: OCTO_AI__INSTANCEPREFIX
  value: {{ .Values.global.instancePrefix }}
- name: OCTO_AI__OCTOMESHMCPSERVICEURL
  value: {{ .Values.global.octoMeshMcpServiceUrl }}
{{- /*
URL the adapter writes into every per-session .mcp.json (AgentWorkspaceMaterializer.
BuildMcpConfigJson). Must point at the chart's own in-cluster MCP Service — the code
default `http://octo-ai-mcp:8080/mcp` does not match the chart-prefixed Service name
(`{release}-mcp`) so without this override claude renders an unresolvable host in the
workspace .mcp.json and every MCP tool call fails with a DNS error. Public HTTPS
endpoints can't be used here because the worker container's CA bundle does not carry
the mm.cloud root cert; the in-cluster http:// path bypasses TLS entirely.
*/}}
{{- /*
Post-chart-split (2026-06-13): octo-mesh-mcp ships as a separate chart, so
the AI chart no longer infers the in-cluster MCP URL from its own values.
Tenant configures `ai.workspace.mcpServerUrl` explicitly — typically
`http://<mcp-release-name>-mcp:<port>/mcp` for an in-cluster octo-mesh-mcp
deployment. Empty leaves the env var unset and the adapter falls back to
the (broken) code default `http://octo-ai-mcp:8080/mcp`, which is the
documented signal that MCP integration isn't wired.
*/}}
{{- if .Values.ai.workspace.mcpServerUrl }}
- name: OCTO_AIWORKSPACE__MCPSERVERURL
  value: {{ .Values.ai.workspace.mcpServerUrl | quote }}
{{- end }}
{{- /*
M3 B-2d: the URL pattern the adapter's PreviewUrlBuilder substitutes
{tenant} + {session} into before rendering the ## Preview block in the
Application JobKind CLAUDE.md. Empty leaves the adapter rendering an
empty preview section (the briefing's workflow step 5 only fires when
the block is present). When `worker.previewIngress.enabled=true` is set,
this should match the chart's tenant subdomain layout, e.g.
`https://{tenant}.preview.test-2.mm.cloud/{session}/`.
*/}}
{{- if .Values.ai.workspace.previewUrlPattern }}
- name: OCTO_AIWORKSPACE__PREVIEWURLPATTERN
  value: {{ .Values.ai.workspace.previewUrlPattern | quote }}
{{- end }}
{{- /*
Bug C fix (chart 0.8.0): ClientCredentials OAuth client the adapter uses to mint a
tenant-scoped access token for the in-cluster MCP server. Both env vars must be set or both
empty — partial config (e.g. clientId without clientSecret) is the same as no config and the
adapter writes an unauthenticated .mcp.json.
*/}}
{{- if and .Values.ai.oauth.clientId .Values.ai.oauth.clientSecret }}
- name: OCTO_AIMCPAUTH__CLIENTID
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh-ai.fullname" .) }}
      key: aiMcpAuthClientId
- name: OCTO_AIMCPAUTH__CLIENTSECRET
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh-ai.fullname" .) }}
      key: aiMcpAuthClientSecret
{{- end }}
{{- /*
AES-256-GCM master key for the adapter's InstanceSecretEncryptionService
(implementation-m1.md §3.5). Emitted only when secrets.aiInstanceSecretKey is
set so unconfigured clusters keep starting (AiEncryptionOptions doc: empty is
tolerated at startup, every encrypt/decrypt call then throws a clear config
error). The byte value must match secrets.communicationInstanceSecretKey in
the octo-mesh chart for cross-replica decrypt to work — operator sets both
to the same Vault-provisioned value (deferred env-var unify task #18 will
collapse this into a single global key).
*/}}
{{- if .Values.global.secrets.aiInstanceSecretKey }}
- name: OCTO_AIENCRYPTION__INSTANCESECRETKEY
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh-ai.fullname" .) }}
      key: aiInstanceSecretKey
{{- end }}
{{- /*
Chart 0.9.0 (M2 carry-over): proactive Anthropic OAuth token-refresh worker.
Without it the per-tenant Anthropic lease access token silently expires after
8h and every session started past that point fails with HTTP 401 until an
operator re-registers from a local Mac keychain. With enabled=true the adapter
ticks every IntervalSeconds and refreshes any lease whose AccessExpiresAt is
within RefreshIfExpiresInSeconds of now. OAuthEndpoint + OAuthClientId are
Anthropic's public Claude Code coordinates — not secret, no Vault round-trip
needed; override only if Anthropic moves the endpoint.
*/}}
{{- if .Values.ai.tokenRefresh.enabled }}
- name: OCTO_AITOKENREFRESH__ENABLED
  value: "true"
- name: OCTO_AITOKENREFRESH__OAUTHENDPOINT
  value: {{ .Values.ai.tokenRefresh.oauthEndpoint | quote }}
- name: OCTO_AITOKENREFRESH__OAUTHCLIENTID
  value: {{ .Values.ai.tokenRefresh.oauthClientId | quote }}
- name: OCTO_AITOKENREFRESH__INTERVALSECONDS
  value: {{ .Values.ai.tokenRefresh.intervalSeconds | quote }}
- name: OCTO_AITOKENREFRESH__REFRESHIFEXPIRESINSECONDS
  value: {{ .Values.ai.tokenRefresh.refreshIfExpiresInSeconds | quote }}
{{- end }}
{{- if .Values.worker.enabled }}
# #4130 Phase C: flip the orchestrator to Mode=Remote and point it at the
# per-tenant worker Service. RemoteAgentWorkerClient substitutes `{tenant}`
# at runtime with the session's tenant id, so a single env var routes every
# tenant to its own pod.
- name: OCTO_AIWORKER__MODE
  value: "Remote"
- name: OCTO_AIWORKER__REMOTEWORKERURL
  value: {{ printf "http://%s-worker-{tenant}:%d/internal/worker/run" (include "octo-mesh-ai.fullname" .) (int .Values.worker.service.port) | quote }}
{{- end }}
{{- end -}}

{{- define "octo-mesh-pro.tenant-generation-enforcement-env" -}}
{{- /*
AB#9027 (AB#9000 switch S2): mode of the tenant generation check (octo-common-services AB#8999,
TenantAuthorization:TenantGenerationEnforcement). Value tenantAuthorization.tenantGenerationEnforcement, same name as
in the octo-mesh chart (octo-helm-core). Rendered explicitly (chart default LogOnly, same as the code default). Only
an unset value (null) or "" falls back to LogOnly; any other value must be LogOnly, Enforce or Disabled as a string,
so a typo, a YAML boolean or a number fails the render instead of silently becoming LogOnly.
Same block in the reporting, mcp and ai charts.
*/ -}}
{{- $mode := dig "tenantGenerationEnforcement" nil (.Values.tenantAuthorization | default dict) }}
{{- if or (kindIs "invalid" $mode) (and (kindIs "string" $mode) (eq $mode "")) }}
{{- $mode = "LogOnly" }}
{{- end }}
{{- if not (and (kindIs "string" $mode) (has $mode (list "LogOnly" "Enforce" "Disabled"))) }}
{{- fail (printf "tenantAuthorization.tenantGenerationEnforcement must be LogOnly, Enforce or Disabled, got '%v'" $mode) }}
{{- end }}
- name: OCTO_TENANTAUTHORIZATION__TENANTGENERATIONENFORCEMENT
  value: {{ $mode | quote }}
{{- end }}

{{- define "octo-mesh-ai.llmGateway-env" -}}
{{- /*
AB#9728: settings of the LLM gateway (octo-ai-services LlmGatewayOptions, section LlmGateway). Rendered only with
ai.llmGateway.enabled=true; otherwise no OCTO_LLMGATEWAY__* variable exists and the gateway refuses every call (fail
closed). With enabled=true a missing key or a rate that is not a positive number fails the render instead of starting a
gateway that answers 503. Key source and cap per tenant are not chart values (AB#8690): they are set with octo-cli
SetAiSpendCap and stored in the system database; the retired value ai.llmGateway.tenants fails the render.
The central key reaches the pod only through the backend Secret (secretKeyRef), never as a value. No AnthropicBaseUrl
value on purpose: the key goes to the provider's default endpoint only.
*/ -}}
{{- $gw := .Values.ai.llmGateway | default dict }}
{{- $rcFlags := $gw.reconciliation | default dict }}
{{- range $flag := list (list "ai.llmGateway.enabled" $gw.enabled) (list "ai.llmGateway.reconciliation.enabled" $rcFlags.enabled) }}
{{- if not (or (kindIs "invalid" (index $flag 1)) (kindIs "bool" (index $flag 1))) }}
{{- fail (printf "%s must be true or false (a boolean, not a string)" (index $flag 0)) }}
{{- end }}
{{- end }}
{{- if eq (toString $gw.enabled) "true" }}
{{- if not $gw.anthropicApiKey }}
{{- fail "ai.llmGateway.enabled=true needs ai.llmGateway.anthropicApiKey (the central key, from Vault)" }}
{{- end }}
{{- $rate := include "octo-mesh-ai.scalarString" $gw.usdToEurRate }}
{{- if not (and (regexMatch "^[0-9]+([.][0-9]+)?$" $rate) (gt (float64 $rate) 0.0)) }}
{{- fail (printf "ai.llmGateway.usdToEurRate must be a positive decimal number, got '%s'" $rate) }}
{{- end }}
{{- $tenants := $gw.tenants | default dict }}
{{- if or (not (kindIs "map" $tenants)) (gt (len $tenants) 0) }}
{{- fail "ai.llmGateway.tenants is retired (AB#8690): key source and cap per tenant are set with octo-cli SetAiSpendCap (stored in the system database); remove ai.llmGateway.tenants" }}
{{- end }}
- name: OCTO_LLMGATEWAY__ANTHROPICAPIKEY
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh-ai.fullname" .) }}
      key: aiLlmGatewayAnthropicApiKey
- name: OCTO_LLMGATEWAY__USDTOEURRATE
  value: {{ $rate | quote }}
{{- include "octo-mesh-ai.llmGateway-reconciliation-env" . }}
{{- else if eq (toString $rcFlags.enabled) "true" }}
{{- fail "ai.llmGateway.reconciliation.enabled=true needs ai.llmGateway.enabled=true (the reconciliation compares the gateway's metered spend)" }}
{{- end }}
{{- end -}}

{{- define "octo-mesh-ai.llmGateway-reconciliation-env" -}}
{{- /*
AB#8694: daily reconciliation of the metered spend with the Anthropic Admin API cost report. Rendered only inside an
enabled gateway with ai.llmGateway.reconciliation.enabled=true; a missing Admin key or workspace id fails the render.
The read-only Admin key reaches the pod only through the backend Secret (secretKeyRef). No Admin API URL value on
purpose: the key goes to the provider's default endpoint only.
*/ -}}
{{- $rc := .Values.ai.llmGateway.reconciliation | default dict }}
{{- if eq (toString $rc.enabled) "true" }}
{{- if not $rc.anthropicAdminApiKey }}
{{- fail "ai.llmGateway.reconciliation.enabled=true needs ai.llmGateway.reconciliation.anthropicAdminApiKey (read-only Admin key, from Vault)" }}
{{- end }}
{{- if not (regexMatch "^wrkspc_[A-Za-z0-9]+$" (include "octo-mesh-ai.scalarString" $rc.workspaceId)) }}
{{- fail (printf "ai.llmGateway.reconciliation.workspaceId must be the id of the central workspace (wrkspc_...), got '%s'" (include "octo-mesh-ai.scalarString" $rc.workspaceId)) }}
{{- end }}
- name: OCTO_LLMGATEWAY__RECONCILIATION__ENABLED
  value: "true"
- name: OCTO_LLMGATEWAY__RECONCILIATION__ANTHROPICADMINAPIKEY
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh-ai.fullname" .) }}
      key: aiLlmGatewayAnthropicAdminApiKey
- name: OCTO_LLMGATEWAY__RECONCILIATION__WORKSPACEID
  value: {{ $rc.workspaceId | quote }}
{{- end }}
{{- end -}}

{{- /* A scalar value as a string; null or missing gives "" (toString would give "<nil>", default would drop 0). */ -}}
{{- define "octo-mesh-ai.scalarString" -}}
{{- if not (kindIs "invalid" .) }}{{ toString . }}{{ end }}
{{- end -}}
