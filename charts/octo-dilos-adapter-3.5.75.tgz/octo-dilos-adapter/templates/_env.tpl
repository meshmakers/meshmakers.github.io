{{/*
  Kubernetes EnvVar.value is typed string, so every env value must render as a
  YAML string scalar. Without `| quote`, values that look like YAML scalars of
  another type (numbers, booleans, "null", "yes/no") get interpreted as that
  type and the apiserver rejects the Deployment with
  "cannot unmarshal number into Go struct field EnvVar.value of type string".
  Specifically: blueprint-seeded RtIds like 670000000000000000000002 are 24
  decimal digits and parse as numbers. `| quote` everywhere — env values are
  always strings.
*/}}
{{- define "octo-mesh.system-env" -}}
- name: OCTO_SYSTEM__DATABASEHOST
  value: {{ .Values.clusterDependencies.mongodbHost | quote }}
{{- if .Values.clusterDependencies.systemDatabaseName }}
{{/*
  Instance isolation (Epic AB#4944): the tenant registry lives in this database, and
  the adapter resolves its own tenant through it on every CK-model load. It must match
  the core services' serviceDefaults.systemDatabaseName; an instance on a non-default
  system database otherwise fails with "Tenant '<id>' does not exist". Omitted when
  unset, so a single-instance cluster keeps the adapter's compiled-in default.
*/}}
- name: OCTO_SYSTEM__SYSTEMDATABASENAME
  value: {{ .Values.clusterDependencies.systemDatabaseName | quote }}
{{- end }}
{{- if .Values.clusterDependencies.mongodbReplicaSet }}
- name: OCTO_SYSTEM__REPLICASETNAME
  value: {{ .Values.clusterDependencies.mongodbReplicaSet | quote }}
{{- end }}
{{ include "octo-mesh.secretEnv" (dict "envName" "OCTO_SYSTEM__DATABASEUSERPASSWORD" "value" .Values.secrets.databaseUser "legacyKey" "databaseUser" "context" .) }}
{{ include "octo-mesh.secretEnv" (dict "envName" "OCTO_SYSTEM__ADMINUSERPASSWORD" "value" .Values.secrets.databaseAdmin "legacyKey" "databaseAdmin" "context" .) }}
{{- end }}

{{- define "octo-mesh.broker-env" -}}
- name: {{ printf "%s__BROKERHOST" (upper .name) }}
  value: {{ .global.Values.clusterDependencies.rabbitMqHost | quote }}
- name: {{ printf "%s__BROKERUSERNAME" (upper .name) }}
  value: {{ .global.Values.clusterDependencies.rabbitMqUser | quote }}
{{ include "octo-mesh.secretEnv" (dict "envName" (printf "%s__BROKERPASSWORD" (upper .name)) "value" .global.Values.secrets.rabbitmq "legacyKey" "rabbitmq" "context" .global) }}
{{- end }}

{{- define "octo-mesh.streamdata-env" -}}
# Instance-level kill switch for StreamData. Read by
# StreamDataInstanceConfiguration (root "StreamData" config section, hence
# the fixed env-var name without a service prefix). Defaults to false so
# the feature is opt-in per cluster.
- name: OCTO_STREAMDATA__ENABLED
  value: {{ .global.Values.clusterDependencies.streamDataEnabled | quote }}
{{- if .global.Values.clusterDependencies.streamDataSchemaInstancePrefix }}
{{/*
  AB#4946 / Epic AB#4944: prefixes the tenant's CrateDB schema so a second instance
  does not read and write the first one's data. Same root "StreamData" config section
  as the kill switch above, hence no service prefix. Omitted when unset — the legacy,
  unprefixed schema names stay byte-identical.
*/}}
- name: OCTO_STREAMDATA__SCHEMAINSTANCEPREFIX
  value: {{ .global.Values.clusterDependencies.streamDataSchemaInstancePrefix | quote }}
{{- end }}
- name: {{ printf "%s__STREAMDATAHOST" (upper .name) }}
  value: {{ .global.Values.clusterDependencies.streamDataHost | quote }}
- name: {{ printf "%s__STREAMDATAUSER" (upper .name) }}
  value: {{ .global.Values.clusterDependencies.streamDataUser | quote }}
{{ include "octo-mesh.secretEnv" (dict "envName" (printf "%s__STREAMDATAPASSWORD" (upper .name)) "value" .global.Values.secrets.streamDataPassword "legacyKey" "streamDataPassword" "context" .global) }}
{{- end }}

{{- /*
  AB#8923: the rule of a value that names something (aspNetCoreEnvironment, logLevel, logLevelRoot,
  minimumLogLevel). The host reads a name, so the value must be text. Unquoted in a values file, true,
  false, yes, no, on, off, y and n are YAML booleans and a plain number is a number; --set reads true,
  false and integers the same way. A `default` or an `if` would read false and 0 as unset, and toString or
  quote would turn true into the name "true", both without a word. So a value that is no text stops the
  render with a message that names the key, the type and the value, shown with toRawJson (a whole number
  such as 1000000 stays in decimal, where %v and toString write 1e+06; toRawJson writes numbers as toJson
  does but leaves <, > and & unescaped; a hex number in a values file arrives as its decimal value and
  cannot be shown as written). A text is trimmed; the result is empty for an unset,
  null, empty or blank value, which keeps the key's default. Parameters: key (its name in the values),
  value, expected (what the message asks for).
*/}}
{{- define "octo-mesh.named-value" -}}
{{- if not (kindIs "invalid" .value) }}
{{- if not (kindIs "string" .value) }}
{{- fail (printf "%s must be a quoted %s; got the %s %s. Unquoted in a values file, true, false, yes, no, on, off, y and n are YAML booleans and a plain number such as 0 or 1 is a number; quote the name there, and pass it with --set-string instead of --set." .key .expected (kindOf .value) (toRawJson .value)) }}
{{- end }}
{{- trim .value }}
{{- end }}
{{- end }}

{{- /*
  AB#8923: a level name is compared without letter case with the names in `names`, but only when it is
  made of ASCII letters: lower folds U+0130 (capital I with dot above) to an ASCII i, so a name such as
  Information with U+0130 in place of the I would pass here and then fail the options binding, or name no
  NLog level, at runtime. Any other name stops the render with a message that lists `names`, the same list
  the comparison reads. Parameters: key, name (the trimmed text), names (in their documented letter case),
  family (what a valid name is), hint (a sentence after the list).
*/}}
{{- define "octo-mesh.check-level-name" -}}
{{- if not (and (regexMatch "^[A-Za-z]+$" .name) (has (lower .name) (splitList "," (lower (join "," .names))))) }}
{{- fail (printf "%s %q is not %s; use %s or %s. %s" .key .name .family (join ", " (initial .names)) (last .names) .hint) }}
{{- end }}
{{- end }}

{{- define "octo-mesh.env" -}}
- name: ASPNETCORE_URLS
  value: "http://+:80"
{{- /*
  AB#8515 / AB#5303: the host environment. The SDK refuses ignoreCertificateValidation only when
  ASPNETCORE_ENVIRONMENT, or else DOTNET_ENVIRONMENT, says Production (ServerCertificateTrust in
  octo-sdk r3.5.66, lines 76 and 160-166): it reads DOTNET_ENVIRONMENT only when ASPNETCORE_ENVIRONMENT
  is empty or whitespace, compares without letter case but untrimmed, and turns validation off when
  neither names Production. Neither the image nor the host sets them, so the chart always renders
  ASPNETCORE_ENVIRONMENT: Production unless aspNetCoreEnvironment names another environment, an empty
  or blank value included. It trims the value, so " Production " cannot pass the SDK as another name.
  Without the variable the host is Production as well, so the default changes nothing else. The guard
  of ignoreCertificateValidation below reads it. AB#8923: the value must be text (octo-mesh.named-value);
  unquoted in a values file, yes rendered the name "true" and let that guard pass, and Off rendered
  Production. Any text is a name; the chart keeps no list of environments.
*/}}
{{- $aspNetCoreEnvironment := include "octo-mesh.named-value" (dict "key" "aspNetCoreEnvironment" "value" .Values.aspNetCoreEnvironment "expected" "environment name such as Production or Test") }}
{{- if not $aspNetCoreEnvironment }}
{{- $aspNetCoreEnvironment = "Production" }}
{{- end }}
- name: ASPNETCORE_ENVIRONMENT
  value: {{ $aspNetCoreEnvironment | quote }}
{{- /*
  AB#5478 §2.1 + §2.2, as in the product's octo-mesh-adapter chart (main 1263a0a): the
  workload's own identity in Dash0. OTEL_SERVICE_NAME is the release name, under the operator
  {tenantId}-{workloadName} and already the app.kubernetes.io/service label, so metrics, traces
  and logs land on the same name; octo.tenant.id carries the tenant as its own dimension.
  Guarded on tenantId because an empty value would publish `octo.tenant.id=` as a real, wrong
  attribute.
*/}}
- name: OTEL_SERVICE_NAME
  value: {{ include "octo-mesh.service-fullname" . | quote }}
{{- if .Values.tenantId }}
- name: OTEL_RESOURCE_ATTRIBUTES
  value: {{ printf "octo.tenant.id=%s" .Values.tenantId | quote }}
{{- end }}
# The SDK's own ActivitySources, declared to the injected .NET auto-instrumentation; the host
# carries the product's mesh-adapter nodes and with them the StreamData engine. Same list as the
# product chart; keep the two in step.
- name: OTEL_DOTNET_AUTO_TRACES_ADDITIONAL_SOURCES
  value: "Meshmakers.Octo.StreamData,Meshmakers.Octo.StreamData.Crate"
{{- /*
  AB#5478 section 2.3, the second of two log stages: nlog.config reads OCTO_LOG_LEVEL (Meshmakers.*)
  and OCTO_LOG_LEVEL_ROOT (everything else), both Info when unset or empty. AB#8923: each value is an
  NLog name as text (octo-mesh.named-value), one of the seven the chart documents (Trace, Debug, Info,
  Warn, Error, Fatal, Off) in any letter case (octo-mesh.check-level-name), trimmed, and renders in the
  letter case it was given; unset, null, empty or blank renders no variable. Any other value stops the
  render. For a name it does not know NLog enables no level of the rule and says so only in its internal
  log (NLog v6.2.0 DynamicRangeLevelFilter.cs lines 90-123), and the final of the Meshmakers.* rule applies
  only to a level the rule enables (TargetWithFilterChain.cs lines 282-290). So true or 1 in both keys
  silenced every line, errors included; in logLevelRoot alone every line outside Meshmakers.*; in logLevel
  alone the Meshmakers.* lines fell through to the * rule. An unquoted Off was a YAML boolean that rendered
  nothing and left the level at Info, and a blank text passed the fallback of nlog.config and was trimmed
  to no level.
*/}}
{{- $nlogLevels := list "Trace" "Debug" "Info" "Warn" "Error" "Fatal" "Off" }}
{{- range $key, $environmentKey := dict "logLevel" "OCTO_LOG_LEVEL" "logLevelRoot" "OCTO_LOG_LEVEL_ROOT" }}
{{- $level := include "octo-mesh.named-value" (dict "key" $key "value" (index $.Values $key) "expected" (printf "log level name (%s)" (join ", " $nlogLevels))) }}
{{- if $level }}
{{- include "octo-mesh.check-level-name" (dict "key" $key "name" $level "names" $nlogLevels "family" "an NLog level" "hint" "Microsoft.Extensions.Logging names such as Information or Warning belong in minimumLogLevel.") }}
- name: {{ $environmentKey }}
  value: {{ $level | quote }}
{{- end }}
{{- end }}
{{- /*
  AB#8515, the first of two log stages: WebAdapterBuilder (octo-communication-sdk) drops every ILogger
  line below AdapterOptions.MinimumLogLevel before it reaches NLog; the SDK's own default is
  Information. The chart always renders it, Trace unless minimumLogLevel says otherwise, so nlog.config
  alone decides what is written and logLevel: Debug alone opens Debug for Meshmakers.*; with default
  values nlog.config stays at Info and writes no Debug line. Only the NLog provider is registered, so
  Trace here changes no output by itself. The value takes the Microsoft.Extensions.Logging names
  (Trace, Debug, Information, Warning, Error, Critical, None) in any letter case, trimmed, and renders
  in the letter case it was given (the binder reads any); unset, null, empty or blank means Trace. Any
  other name, an NLog name such as Info included, would fail the options binding at startup and leave
  the pod restarting, so the chart refuses it here instead. It refuses a value that is no text as well:
  unquoted in a values file, Off, No and false are YAML booleans and 0 is a number, and a `default`
  would have turned them into Trace without a word (octo-mesh.named-value). Only names of ASCII letters
  pass (octo-mesh.check-level-name, AB#8923). No other value is mapped into it.
*/}}
{{- $loggingLevels := list "Trace" "Debug" "Information" "Warning" "Error" "Critical" "None" }}
{{- $minimumLogLevel := include "octo-mesh.named-value" (dict "key" "minimumLogLevel" "value" .Values.minimumLogLevel "expected" (printf "log level name (%s)" (join ", " $loggingLevels))) | default "Trace" }}
{{- include "octo-mesh.check-level-name" (dict "key" "minimumLogLevel" "name" $minimumLogLevel "names" $loggingLevels "family" "a Microsoft.Extensions.Logging level" "hint" "NLog names such as Info or Warn belong in logLevel and logLevelRoot.") }}
- name: OCTO_ADAPTER__MINIMUMLOGLEVEL
  value: {{ $minimumLogLevel | quote }}
{{- $name := "OCTO_ADAPTER" }}
{{ include "octo-mesh.system-env" . }}
{{ include "octo-mesh.broker-env" (dict "global" . "name" $name) }}
{{ include "octo-mesh.streamdata-env" (dict "global" . "name" $name) }}
- name: OCTO_ADAPTER__INSTANCEPREFIX
  value: {{ .Values.instancePrefix | quote }}
{{- /*
  AB#4924 increment 3: the SDK binds the old OCTO_ADAPTER__TENANTID only for one deprecation
  release (ConfigureLegacyAdapterTenantId, with a warning on every start); without either key the
  adapter falls back to the "meshTest" default and connects on the wrong tenant route.
  DEDICATEDTENANTID is the key the product chart renders: the single tenant this adapter is
  pinned to, for its hub route and its own credential.
*/}}
- name: OCTO_ADAPTER__DEDICATEDTENANTID
  value: {{ .Values.tenantId | quote }}
- name: OCTO_ADAPTER__COMMUNICATIONCONTROLLERSERVICESURI
  value: {{ .Values.communicationControllerServiceUri | quote }}
{{- if eq (lower (toString .Values.ignoreCertificateValidation)) "true" }}
{{- if eq (lower $aspNetCoreEnvironment) "production" }}
{{- fail (printf "ignoreCertificateValidation is true, but aspNetCoreEnvironment is %q: the chart refuses to turn off TLS certificate validation in Production. Keep validation on with ignoreCertificateValidation: false and the cluster's CA in secrets.rootCa, or, on development and private-PKI clusters only, set aspNetCoreEnvironment to a non-production name such as Test." $aspNetCoreEnvironment) }}
{{- end }}
{{/*
  AB#5303 items 1+2, AB#8515. Rendered ONLY for the value true, as a boolean or as text in any letter
  case, never `false`: an absent variable and a false one mean the same to the SDK, and an absent one
  cannot be mistaken for a deliberate choice. A value override of the communication controller can
  arrive as text, and a guard that only asked whether the value is set read "false" as true. It turns
  off TLS certificate validation for every outgoing Octo call of the process. The SDK refuses it only
  when ASPNETCORE_ENVIRONMENT says Production, or, when that is empty or whitespace, DOTNET_ENVIRONMENT
  (ServerCertificateTrust in octo-sdk r3.5.66, lines 76 and 160-166); this chart renders
  ASPNETCORE_ENVIRONMENT above, Production by default, and refuses the value true itself while it says
  Production, so the unsafe mode needs an explicit non-production environment. The communication
  operator projects ignoreCertificateValidation: true into every workload on test-2, so a workload
  there needs ignoreCertificateValidation: false (recommended, the CA arriving as secrets.rootCa) or,
  on a cluster without a CA, aspNetCoreEnvironment: Test in its values before it moves to this chart
  version; otherwise the render stops here and the deploy of the new version with it.
*/}}
- name: OCTO_ADAPTER__IGNORECERTIFICATEVALIDATION
  value: "true"
{{- end }}
- name: OCTO_ADAPTER__ADAPTERCKTYPEID
  value: "System.Communication/Adapter"
- name: OCTO_ADAPTER__ADAPTERRTID
  value: {{ .Values.adapterRtId | quote }}
- name: OCTO_ADAPTER__REPORTINGSERVICEURL
  value: {{ .Values.reportingServiceUri | quote }}
{{/*
  AB#5072 / AB#6669 -- ONE chart value, TWO opposite directions.

  AUTHORITYURL is INBOUND: the issuer that secured FromHttpRequest@2 routes accept
  on tokens presented TO this adapter. It lives on MeshAdapterConfiguration, which
  Program.cs configures (Octo.Sdk.MeshAdapter, shared by every mesh-node adapter,
  this one included) and ConfigureJwtBearerOptions reads. Without it the compiled-in
  default stays https://localhost:5003; outside Development that is loopback, so the
  adapter logs "Adapter:AuthorityUrl ... JWT bearer authentication is therefore
  disabled" at startup and every caller of a secured route is denied with HTTP 401.
  The weclapp chart this one descends from used to omit it on the (outdated)
  assumption that the adapter has no MeshAdapterConfiguration; it has (AB#6669).

  ISSUERURI is OUTBOUND: the identity the adapter presents when it connects to
  /{tenantId}/adapterHub. Read by AdapterOptions in octo-communication-sdk, which
  every SDK-based adapter shares, so that key is deliberately byte-identical
  across the adapter charts.

  Both are fed from the SAME `authUri` on purpose -- one identity service issues
  and validates both directions, so a second chart value could only ever drift.
  Same block as the octo-mesh-adapter and octo-eda-adapter charts.

  `authUri` needs no new plumbing: the communication operator writes it into the
  context values of EVERY workload (WorkloadContextValuesBuilder). It must be the
  PUBLIC issuer address -- OIDC discovery runs against it in both directions, and
  the communication controller validates the issuer of the resulting token.
*/}}
{{- if .Values.authUri }}
- name: OCTO_ADAPTER__AUTHORITYURL
  value: {{ .Values.authUri | quote }}
- name: OCTO_ADAPTER__ISSUERURI
  value: {{ .Values.authUri | quote }}
{{- end }}
{{/*
  Client id of the adapter's own confidential OAuth client -- the
  ServiceAccountConfiguration the communication controller provisions per adapter
  (AB#5027) and projects onto this exact path as a ValueOverride at deploy time.
  Omitted when unset: AdapterOptions.IsEnabled is `IssuerUri && ClientId`, so an
  unconfigured adapter acquires no token and connects anonymously -- which is what
  the whole fleet does today and must keep doing on upgrade.
*/}}
{{- if .Values.serviceAccountClientId }}
- name: OCTO_ADAPTER__CLIENTID
  value: {{ .Values.serviceAccountClientId | quote }}
{{- end }}
{{/*
  🔴 Secret-flagged on the controller side, so the operator materialises it into
  {release}-octo-secrets and hands this path a {valueFrom: {secretKeyRef: ...}} map
  instead of the plaintext -- octo-mesh.secretEnv accepts both shapes, exactly as
  secrets.rabbitmq does. Guarded by `if` because secretEnv FAILS on an empty value
  (deliberate for the four mandatory cluster secrets) while this one is optional by
  design -- see the ClientId note above.
*/}}
{{- if .Values.secrets.serviceAccountClientSecret }}
{{ include "octo-mesh.secretEnv" (dict "envName" "OCTO_ADAPTER__CLIENTSECRET" "value" .Values.secrets.serviceAccountClientSecret "legacyKey" "serviceAccountClientSecret" "context" .) }}
{{- end }}
{{- end }}
