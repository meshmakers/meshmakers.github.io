{{- define "octo-mesh.system-env" -}}
- name: OCTO_SYSTEM__DATABASEHOST
  value: {{ .Values.clusterDependencies.mongodbHost }}
{{- if .Values.clusterDependencies.mongodbReplicaSet }}
- name: OCTO_SYSTEM__REPLICASETNAME
  value: {{ .Values.clusterDependencies.mongodbReplicaSet }}
{{- end }}
{{ include "octo-mesh.secretEnv" (dict "envName" "OCTO_SYSTEM__DATABASEUSERPASSWORD" "value" .Values.secrets.databaseUser "legacyKey" "databaseUser" "context" .) }}
{{ include "octo-mesh.secretEnv" (dict "envName" "OCTO_SYSTEM__ADMINUSERPASSWORD" "value" .Values.secrets.databaseAdmin "legacyKey" "databaseAdmin" "context" .) }}
{{- end }}

{{- define "octo-mesh.broker-env" -}}
- name: {{ printf "%s__BROKERHOST" (upper .name) }}
  value: {{ .global.Values.clusterDependencies.rabbitMqHost }}
- name: {{ printf "%s__BROKERUSERNAME" (upper .name) }}
  value: {{ .global.Values.clusterDependencies.rabbitMqUser }}
{{ include "octo-mesh.secretEnv" (dict "envName" (printf "%s__BROKERPASSWORD" (upper .name)) "value" .global.Values.secrets.rabbitmq "legacyKey" "rabbitmq" "context" .global) }}
{{- end }}

{{- define "octo-mesh.streamdata-env" -}}
# Instance-level kill switch for StreamData. Read by
# StreamDataInstanceConfiguration (root "StreamData" config section, hence
# the fixed env-var name without a service prefix). Defaults to false so
# the feature is opt-in per cluster.
- name: OCTO_STREAMDATA__ENABLED
  value: {{ .global.Values.clusterDependencies.streamDataEnabled | quote }}
- name: {{ printf "%s__STREAMDATAHOST" (upper .name) }}
  value: {{ .global.Values.clusterDependencies.streamDataHost }}
- name: {{ printf "%s__STREAMDATAUSER" (upper .name) }}
  value: {{ .global.Values.clusterDependencies.streamDataUser }}
{{ include "octo-mesh.secretEnv" (dict "envName" (printf "%s__STREAMDATAPASSWORD" (upper .name)) "value" .global.Values.secrets.streamDataPassword "legacyKey" "streamDataPassword" "context" .global) }}
{{- end }}


{{- define "octo-mesh.env" -}}
- name: ASPNETCORE_URLS
  value: "http://+:80"
{{- /*
  AB#5478 §2.1 + §2.2 — per-tenant identity for this workload.

  Both halves of the identity were collapsed across tenants before this. The pod
  label app.kubernetes.io/name is the CHART name, identical for every adapter of
  every tenant in the cluster, and the in-process SDK fell back to the entry
  assembly name, equally shared. So every tenant's adapter arrived in Dash0 as a
  single service — measured on test-2: 127,976 requests at p95 3.19 s with no way
  to tell whose latency that was.

  OTEL_SERVICE_NAME is the release name, which under the operator already reads
  {tenantId}-{workloadName} and is already the value of the
  app.kubernetes.io/service label. Metrics, traces and logs therefore land on the
  SAME name: metrics and traces because container env beats everything the operator
  would otherwise derive, logs because the Dash0Monitoring transform reads that
  label. One value, three signals.

  octo.tenant.id carries the tenant as its own dimension on every span, metric and
  log record of this pod, with no code change. One spelling fleet-wide — the
  engine's own `tenant` / `streamdata.tenant` attributes are being unified onto
  this key, so do not introduce a fourth.

  Guarded on tenantId because the chart defaults it to "" for out-of-band installs;
  an empty value would publish `octo.tenant.id=` as a real, wrong attribute.
*/}}
- name: OTEL_SERVICE_NAME
  value: {{ include "octo-mesh.service-fullname" . | quote }}
{{- if .Values.tenantId }}
- name: OTEL_RESOURCE_ATTRIBUTES
  value: {{ printf "octo.tenant.id=%s" .Values.tenantId | quote }}
{{- end }}
{{- $name := "OCTO_ADAPTER" }}
{{ include "octo-mesh.system-env" . }}
{{ include "octo-mesh.broker-env" (dict "global" . "name" $name) }} 
{{ include "octo-mesh.streamdata-env" (dict "global" . "name" $name) }}
- name: OCTO_ADAPTER__INSTANCEPREFIX
  value: {{ .Values.instancePrefix }}
- name: OCTO_ADAPTER__TENANTID
  value: {{ .Values.tenantId }}
- name: OCTO_ADAPTER__COMMUNICATIONCONTROLLERSERVICESURI
  value: {{ .Values.communicationControllerServiceUri }}
- name: OCTO_ADAPTER__ADAPTERCKTYPEID
  value: "System.Communication/Adapter"              
- name: OCTO_ADAPTER__ADAPTERRTID
  value: {{ .Values.adapterRtId }}
- name: OCTO_ADAPTER__REPORTINGSERVICEURL
  value: {{ .Values.reportingServiceUri }}
{{/*
  AB#5072 -- ONE chart value, TWO opposite directions.

  AUTHORITYURL is INBOUND: the issuer that secured FromHttpRequest@2 routes accept
  on tokens presented TO this adapter. It lives on MeshAdapterConfiguration, which
  Program.cs binds from the "Adapter" section and ConfigureJwtBearerOptions reads
  (octo-mesh-adapter's MeshAdapter.Sdk -- shared by every mesh-node adapter, this
  one included). Without it the compiled-in default stays https://localhost:5003;
  outside Development that is loopback, so UseOctoMeshAdapter skips the
  authentication middleware entirely and every caller of a secured route is denied
  with HTTP 401 -- which is what every deployed EDA adapter did while this chart
  rendered ISSUERURI alone.

  ISSUERURI is OUTBOUND: the identity the adapter presents when it connects to
  /{tenantId}/adapterHub. Read by AdapterOptions in octo-communication-sdk, which
  every SDK-based adapter shares, so that key is deliberately byte-identical
  across the adapter charts.

  Both are fed from the SAME `authUri` on purpose -- one identity service issues
  and validates both directions, so a second chart value could only ever drift.
  The two config keys exist because AdapterOptions lives in the SDK and must also
  serve adapters that have no MeshAdapterConfiguration (Loxone, Modbus, Zenon);
  the chart is where they are tied back together.

  `authUri` needs no new plumbing: the communication operator writes it into the
  context values of EVERY workload (WorkloadContextValuesBuilder). It must be the
  PUBLIC issuer address -- OIDC discovery runs against it in both directions, and
  the communication controller validates the issuer of the resulting token.
*/}}
{{- if .Values.authUri }}
- name: OCTO_ADAPTER__AUTHORITYURL
  value: {{ .Values.authUri | quote }}
- name: OCTO_ADAPTER__ISSUERURI
  value: {{ .Values.authUri | quote }}
{{- end }}
{{/*
  Client id of the adapter's own confidential OAuth client -- the
  ServiceAccountConfiguration the communication controller provisions per adapter
  (AB#5027) and projects onto this exact path as a ValueOverride at deploy time.
  Omitted when unset: AdapterOptions.IsEnabled is `IssuerUri && ClientId`, so an
  unconfigured adapter acquires no token and connects anonymously -- which is what
  the whole fleet does today and must keep doing on upgrade.
*/}}
{{- if .Values.serviceAccountClientId }}
- name: OCTO_ADAPTER__CLIENTID
  value: {{ .Values.serviceAccountClientId | quote }}
{{- end }}
{{/*
  🔴 Secret-flagged on the controller side, so the operator materialises it into
  {release}-octo-secrets and hands this path a {valueFrom: {secretKeyRef: ...}} map
  instead of the plaintext -- octo-mesh.secretEnv accepts both shapes, exactly as
  secrets.rabbitmq does. Guarded by `if` because secretEnv FAILS on an empty value
  (deliberate for the four mandatory cluster secrets) while this one is optional by
  design -- see the ClientId note above.
*/}}
{{- if .Values.secrets.serviceAccountClientSecret }}
{{ include "octo-mesh.secretEnv" (dict "envName" "OCTO_ADAPTER__CLIENTSECRET" "value" .Values.secrets.serviceAccountClientSecret "legacyKey" "serviceAccountClientSecret" "context" .) }}
{{- end }}
{{- end }}