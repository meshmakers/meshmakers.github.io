{{- define "octo-mesh.system-env" -}}
- name: OCTO_SYSTEM__SYSTEMDATABASENAME
  value: {{ .Values.global.systemDatabaseName }}
- name: OCTO_SYSTEM__DATABASEHOST
  value: {{ .Values.global.clusterDependencies.mongodbHost }}
- name: OCTO_SYSTEM__DATABASEUSERPASSWORD
  valueFrom:
    secretKeyRef:
        name: {{ printf "%s-backend" (include "octo-mesh-mcp.fullname" .) }}
        key: databaseUser
- name: OCTO_SYSTEM__ADMINUSERPASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh-mcp.fullname" .) }}
      key: databaseAdmin
{{- end -}}

{{- define "octo-mesh.broker-env" -}}
- name: {{ printf "%s__BROKERHOST" (upper .name) }}
  value: {{ .global.Values.global.clusterDependencies.rabbitMqHost }}
- name: {{ printf "%s__BROKERUSER" (upper .name) }}
  value: {{ .global.Values.global.clusterDependencies.rabbitMqUser }}
- name: {{ printf "%s__BROKERPASSWORD" (upper .name) }}
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh-mcp.fullname" .global) }}
      key: rabbitmq
{{- end -}}

{{- define "octo-mesh.streamdata-env" -}}
# Instance-level kill switch for StreamData. Read by
# StreamDataInstanceConfiguration (root "StreamData" config section, hence
# the fixed env-var name without a service prefix). Defaults to false so
# the feature is opt-in per cluster.
#
# AB#4232: live since octo-mcp-service 1.5.x — the McpServices Program.cs
# now calls AddCrateDbStreamDataRepository<ConfigureMcpStreamDataConfiguration>()
# which binds OCTO_MCP__STREAMDATAHOST / __USER / __PASSWORD into
# Mcp.StreamData{Host,User,Password} on McpServiceOptions. Pre-1.5.x the
# env vars below landed in the pod but were never read.
- name: OCTO_STREAMDATA__ENABLED
  value: {{ .global.Values.global.clusterDependencies.streamDataEnabled | quote }}
- name: {{ printf "%s__STREAMDATAHOST" (upper .name) }}
  value: {{ .global.Values.global.clusterDependencies.streamDataHost }}
- name: {{ printf "%s__STREAMDATAUSER" (upper .name) }}
  value: {{ .global.Values.global.clusterDependencies.streamDataUser }}
- name: {{ printf "%s__STREAMDATAPASSWORD" (upper .name) }}
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh-mcp.fullname" .global) }}
      key: streamDataPassword
{{- end -}}

{{- define "octo-mesh-mcp.env" -}}
{{- $name := "OCTO_MCP" }}
{{- /*
  AB#5478 §2.1 — one service.name per process.

  Unlike the octo-mesh chart, the pod label app.kubernetes.io/name is already
  distinct here (it is the chart name), so traces and logs were never wrong. The
  in-process SDK was: without OTEL_SERVICE_NAME it falls back to the entry assembly
  name, so this service's custom metrics arrived in Dash0 as
  Meshmakers.Octo.Backend.McpServices while its spans sat under octo-mesh-mcp —
  two entities for one pod, and no dashboard able to join them.

  The value deliberately matches the label rather than introducing a third spelling.
*/}}
- name: OTEL_SERVICE_NAME
  value: {{ include "octo-mesh-mcp.name" . | quote }}
{{- /*
  Our own ActivitySources, declared to the injected .NET auto-instrumentation. This
  service hosts the same StreamData engine as the platform services, and the
  in-process TracerProvider deliberately carries no exporter (a second one would
  duplicate every HTTP span the injector already sends), so naming the sources here
  is what gets those spans out. Mirrors the identical block in
  octo-helm-core/src/octo-mesh/templates/_env.tpl — keep the two lists in step.
*/}}
- name: OTEL_DOTNET_AUTO_TRACES_ADDITIONAL_SOURCES
  value: "Meshmakers.Octo.StreamData,Meshmakers.Octo.StreamData.Crate"
{{ include "octo-mesh.system-env" . }}
{{ include "octo-mesh.broker-env" (dict "global" . "name" $name) }}
{{ include "octo-mesh.streamdata-env" (dict "global" . "name" $name) }}
- name: OCTO_MCP__AUTHORITYURL
  value: {{ .Values.global.authUri }}
- name: OCTO_MCP__PUBLICURL
  value: {{ .Values.mcp.publicUri }}
- name: OCTO_MCP__INSTANCEPREFIX
  value: {{ .Values.global.instancePrefix }}
{{- /*
Chart 0.10.0 (M2 carry-over): in-cluster URLs for the OctoMesh backend services
the MCP server's SDK-backed tools talk HTTP to (family 1: BlueprintTools,
IdentityTools, AdapterTools, etc.). Without these the tools surface
"Connection refused" or "AssetServiceUrl is not configured" on the first call.
OctoServiceUrls is bound by GetSection("OctoServiceUrls") at root, so the env
var key is OCTO_OCTOSERVICEURLS__<field>, NOT OCTO_MCP__... .
*/}}
{{- if .Values.mcp.octoServiceUrls.asset }}
- name: OCTO_OCTOSERVICEURLS__ASSETSERVICEURL
  value: {{ .Values.mcp.octoServiceUrls.asset | quote }}
{{- end }}
{{- if .Values.mcp.octoServiceUrls.identity }}
- name: OCTO_OCTOSERVICEURLS__IDENTITYSERVICEURL
  value: {{ .Values.mcp.octoServiceUrls.identity | quote }}
{{- end }}
{{- if .Values.mcp.octoServiceUrls.communication }}
- name: OCTO_OCTOSERVICEURLS__COMMUNICATIONSERVICEURL
  value: {{ .Values.mcp.octoServiceUrls.communication | quote }}
{{- end }}
{{- if .Values.mcp.octoServiceUrls.bot }}
- name: OCTO_OCTOSERVICEURLS__BOTSERVICEURL
  value: {{ .Values.mcp.octoServiceUrls.bot | quote }}
{{- end }}
{{- if .Values.mcp.octoServiceUrls.reporting }}
- name: OCTO_OCTOSERVICEURLS__REPORTINGSERVICEURL
  value: {{ .Values.mcp.octoServiceUrls.reporting | quote }}
{{- end }}
{{- /* adminPanel retired in Phase 4 (AB#4261) — no OCTO_OCTOSERVICEURLS__ADMINPANELURL. */}}
{{- end -}}
