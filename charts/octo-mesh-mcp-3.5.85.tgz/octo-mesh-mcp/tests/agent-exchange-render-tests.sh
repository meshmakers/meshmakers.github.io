#!/usr/bin/env bash
# Render tests of the agent-exchange client secret of the octo-mesh-mcp chart (AB#6054):
# mcp.agentExchangeClientSecret -> OCTO_MCP__AGENTEXCHANGECLIENTSECRET (secretKeyRef to the backend Secret) and a pod
# checksum annotation. The value is OPTIONAL: unset, empty or blank must render exactly as before and never fail the
# render (a failing render breaks every CD run of the chart).
# Needs only `helm` (no cluster). Run: bash src/octo-mesh-mcp/tests/agent-exchange-render-tests.sh
set -u
CHART="$(cd "$(dirname "$0")/.." && pwd)"
FAILED=0
# A recognisable fake value: it must never appear in clear text in a rendered manifest.
SECRET="fake-exchange-secret-ab6054"
SECRET_B64="$(printf '%s' "$SECRET" | base64)"
ENV=OCTO_MCP__AGENTEXCHANGECLIENTSECRET
KEY=mcpAgentExchangeClientSecret

check() { local name="$1"; shift; if "$@"; then echo "ok   - $name"; else echo "FAIL - $name"; FAILED=1; fi; }
render() { helm template t "$CHART" "$@" 2>&1; }
# The output is a rendered manifest, not an error (absence checks are vacuous on a failed render).
rendered() { grep -q 'name: OCTO_MCP__AUTHORITYURL' <<<"$1"; }
absent() { ! grep -q -- "$2" <<<"$1"; }
unset_everywhere() {
  rendered "$1" && absent "$1" "$ENV" && absent "$1" "$KEY" && absent "$1" 'checksum/agent-exchange-secret'
}

BASE="$(render)"
check "default renders (test is not vacuous)"          rendered "$BASE"
check "default: no env, no Secret key, no annotation"  unset_everywhere "$BASE"
check "default: no annotations block without podAnnotations" absent "$BASE" 'annotations:'

OUT="$(render --set mcp.agentExchangeClientSecret=)"
check "empty value renders and leaves everything out"  unset_everywhere "$OUT"
OUT="$(render --set 'mcp.agentExchangeClientSecret= ')"
check "blank value renders and leaves everything out"  unset_everywhere "$OUT"
OUT="$(render --set mcp.agentExchangeClientSecret=null)"
check "null value (--set null) renders and leaves everything out" unset_everywhere "$OUT"
OUT="$(render --set mcp.agentExchangeClientSecret=123)"
check "numeric value (non-string) renders and leaves everything out" unset_everywhere "$OUT"
OUT="$(render --set mcp.agentExchangeClientSecret=true)"
check "boolean value (non-string) renders and leaves everything out" unset_everywhere "$OUT"
OUT="$(render --set-json 'mcp.agentExchangeClientSecret={"a":1}')"
check "map value (non-string) renders and leaves everything out" unset_everywhere "$OUT"

OUT="$(render --set "mcp.agentExchangeClientSecret=$SECRET")"
check "set: renders (test is not vacuous)"             rendered "$OUT"
check "set: env var rendered once"                     test "$(grep -c "name: $ENV" <<<"$OUT")" = 1
check "set: env var comes from the backend Secret key" bash -c 'grep -A4 "name: '"$ENV"'" <<<"$0" | grep -q "key: '"$KEY"'"' "$OUT"
check "set: secretKeyRef names the chart backend Secret" bash -c 'grep -A4 "name: '"$ENV"'" <<<"$0" | grep -q "name: t-octo-mesh-mcp-backend"' "$OUT"
check "set: Secret carries the base64 value under the key" grep -q "$KEY: \"$SECRET_B64\"" <<<"$OUT"
check "set: no clear-text value in the manifest"       absent "$OUT" "$SECRET"
check "set: pod checksum annotation present"           grep -q 'checksum/agent-exchange-secret: "' <<<"$OUT"
OUT_SPACED="$(render --set "mcp.agentExchangeClientSecret=  $SECRET  ")"
check "set: surrounding blanks are trimmed (same render)" test "$OUT" = "$OUT_SPACED"

OUT2="$(render --set "mcp.agentExchangeClientSecret=${SECRET}-rotated")"
A="$(grep 'checksum/agent-exchange-secret' <<<"$OUT")"
B="$(grep 'checksum/agent-exchange-secret' <<<"$OUT2")"
check "rotation: a new value changes the checksum (pod rolls)" test -n "$A" -a "$A" != "$B"

OUT="$(render --set "mcp.agentExchangeClientSecret=$SECRET" --set 'mcp.podAnnotations.team=ops')"
check "set + podAnnotations: both annotations render"  bash -c 'grep -q "team: ops" <<<"$0" && grep -q "checksum/agent-exchange-secret" <<<"$0"' "$OUT"
OUT="$(render --set 'mcp.podAnnotations.team=ops')"
check "podAnnotations only: unchanged, no checksum"    bash -c 'grep -q "team: ops" <<<"$0" && ! grep -q "checksum/agent-exchange-secret" <<<"$0"' "$OUT"

exit $FAILED
