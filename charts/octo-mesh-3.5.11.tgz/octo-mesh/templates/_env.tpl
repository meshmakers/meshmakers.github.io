{{- define "octo-mesh.system-env" -}}
- name: OCTO_SYSTEM__SYSTEMDATABASENAME
  value: {{ .global.Values.serviceDefaults.systemDatabaseName }}
- name: OCTO_SYSTEM__DATABASEHOST
  value: {{ .global.Values.clusterDependencies.mongodbHost }}
{{- if .global.Values.clusterDependencies.mongodbReplicaSet }}
- name: OCTO_SYSTEM__REPLICASETNAME
  value: {{ .global.Values.clusterDependencies.mongodbReplicaSet }}
{{- end }}
- name: OCTO_SYSTEM__DATABASEUSERPASSWORD
  valueFrom:
    secretKeyRef:
        name: {{ printf "%s-backend" (include "octo-mesh.fullname" .global) }}
        key: databaseUser
- name: OCTO_SYSTEM__ADMINUSERPASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh.fullname" .global) }}
      key: databaseAdmin          
{{- /*
SECRET attribute key ring (AB#5536). Part of system-env so EVERY engine host in
this chart gets it — the engine binds SecretEncryption:* in AddRuntimeEngine().
Values live in the backend Secret; see "octo-mesh.secretEncryption" in
_helpers.tpl for how the ring is derived from the instance secret.
*/}}
{{- $fullname := include "octo-mesh.fullname" .global }}
{{- $ring := fromJson (include "octo-mesh.secretEncryption" .global) }}
{{- range $kid, $_ := $ring.keys }}
- name: OCTO_SECRETENCRYPTION__KEYS__{{ $kid }}
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" $fullname }}
      key: {{ printf "secretEncryptionKey-%s" $kid }}
{{- end }}
{{- if $ring.keys }}
- name: OCTO_SECRETENCRYPTION__ACTIVEKEYID
  value: {{ $ring.activeKeyId | quote }}
{{- end }}
{{- if $ring.legacyV1Key }}
- name: OCTO_SECRETENCRYPTION__LEGACYV1KEY
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" $fullname }}
      key: communicationInstanceSecretKey
{{- end }}
{{- end }}

{{- define "octo-mesh.broker-env" -}}
- name: {{ printf "%s__BROKERHOST" (upper .name) }}
  value: {{ .global.Values.clusterDependencies.rabbitMqHost }}
- name: {{ printf "%s__BROKERUSER" (upper .name) }}
  value: {{ .global.Values.clusterDependencies.rabbitMqUser }}
- name: {{ printf "%s__BROKERPASSWORD" (upper .name) }}
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh.fullname" .global) }}
      key: rabbitmq     
{{- end }}

{{- define "octo-mesh.blueprints-env" -}}
# Variables surfaced to the blueprint runner via IBlueprintVariableProvider.
# - ${octo.version}: chart appVersion → blueprints can pin Mesh-Adapter ChartVersion
#                    etc. to the current release without manual bumps.
# - ${octo.environment}: dev/test/staging/production gate for `requires:` blocks.
# - ${octo.systemTenantId}: kept in sync with serviceDefaults.systemDatabaseName so
#                          ${octo.isSystemTenant} matches the runtime's system tenant.
# - ${octo.scheme}/${octo.domain}: per-cluster URL composition inputs for
#   ${octo.scheme}://<slug>.${octo.domain} (e.g. ${octo.mcp.publicUrl} in the
#   System.Identity.Bootstrap seed). Explicit serviceDefaults.scheme/.domain win;
#   otherwise both are derived from services.identity.publicUri (scheme verbatim,
#   domain = host minus its first label: https://connect.test-2.mm.cloud →
#   test-2.mm.cloud). Leaving them empty seeds half-composed URLs ("/") into
#   blueprint-managed entities — the AB#4338 invalid_target failure on test-2.
{{- $identityUrl := urlParse (default "" .global.Values.services.identity.publicUri) }}
{{- $derivedDomain := "" }}
{{- if $identityUrl.host }}
{{- $derivedDomain = (splitList "." $identityUrl.host) | rest | join "." }}
{{- end }}
- name: OCTO_BLUEPRINTS__OCTOVERSION
  value: {{ .global.Chart.AppVersion | quote }}
- name: OCTO_BLUEPRINTS__ENVIRONMENT
  value: {{ .global.Values.serviceDefaults.environment | quote }}
- name: OCTO_BLUEPRINTS__SYSTEMTENANTID
  value: {{ .global.Values.serviceDefaults.systemDatabaseName | quote }}
- name: OCTO_BLUEPRINTS__SCHEME
  value: {{ .global.Values.serviceDefaults.scheme | default ($identityUrl.scheme | default "https") | quote }}
- name: OCTO_BLUEPRINTS__DOMAIN
  value: {{ .global.Values.serviceDefaults.domain | default $derivedDomain | quote }}
{{- end }}

{{- define "octo-mesh.streamdata-env" -}}
# Instance-level kill switch for StreamData. Read by
# StreamDataInstanceConfiguration (root "StreamData" config section, hence
# the fixed env-var name without a service prefix). Defaults to false so
# the feature is opt-in per cluster.
- name: OCTO_STREAMDATA__ENABLED
  value: {{ .global.Values.clusterDependencies.streamDataEnabled | quote }}
{{- if .global.Values.clusterDependencies.streamDataSchemaInstancePrefix }}
# CrateDB schema instance prefix (AB#4946, Epic AB#4944): a second OctoMesh instance sharing
# the cluster's CrateDB names its tenant schemas {prefix}_{tenantId}. Same root "StreamData"
# section as the kill switch above, so the env-var name is fixed across services. Emitted only
# when set — existing instances keep their un-prefixed schemas.
- name: OCTO_STREAMDATA__SCHEMAINSTANCEPREFIX
  value: {{ .global.Values.clusterDependencies.streamDataSchemaInstancePrefix | quote }}
{{- end }}
- name: {{ printf "%s__STREAMDATAHOST" (upper .name) }}
  value: {{ .global.Values.clusterDependencies.streamDataHost }}
- name: {{ printf "%s__STREAMDATAUSER" (upper .name) }}
  value: {{ .global.Values.clusterDependencies.streamDataUser }}
- name: {{ printf "%s__STREAMDATAPASSWORD" (upper .name) }}
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh.fullname" .global) }}
      key: streamDataPassword
{{- end }}


{{- define "octo-mesh.env" -}}
- name: ASPNETCORE_URLS
  value: "http://+:80"
# Distinct OpenTelemetry service.name per workload. Without this the Dash0
# auto-instrumentation derives service.name from the app.kubernetes.io/name
# label, which is identical ("octo-mesh") for every service in this release —
# so all services collapse into a single node in the Dash0 service map. The
# injector honours an explicit OTEL_SERVICE_NAME over that label default
# (verified on test-2). Value matches the app.kubernetes.io/service label.
- name: OTEL_SERVICE_NAME
  value: {{ include "octo-mesh.service-fullname" (dict "global" .global "name" .name "svc" .svc) | quote }}
# Our own ActivitySources, declared to the injected .NET auto-instrumentation.
# The services also subscribe to these in Meshmakers.Octo.Services.Observability,
# which is what makes the Activities exist at all — but that in-process
# TracerProvider deliberately has no exporter in the cluster (a second exporter
# would duplicate every HTTP span the injector already sends). Naming the
# sources here is what gets the spans OUT, through the injector's provider.
# Harmless on a service that never emits on them: an unknown source name costs
# one idle listener.
#
# MongoDB.Driver (3.x native tracing, one CLIENT span per command) is added
# when tracing.mongoDb is on, so a slow request shows its database calls
# instead of a childless server span (AB#6307). Switchable per cluster because
# it multiplies the span volume of database-heavy services.
- name: OTEL_DOTNET_AUTO_TRACES_ADDITIONAL_SOURCES
  value: "Meshmakers.Octo.StreamData,Meshmakers.Octo.StreamData.Crate{{ if .global.Values.tracing.mongoDb }},MongoDB.Driver{{ end }}"
{{- /*
  AB#5478 section 2.3: nlog.config takes the log level from the environment
  instead of having it pinned in the repository. Both are omitted unless set, and
  nlog.config then falls back to Info. See values.yaml for why a one-off
  investigation is better served by DiagnosticsService than by these.
*/}}
{{- if .global.Values.logLevel }}
- name: OCTO_LOG_LEVEL
  value: {{ .global.Values.logLevel | quote }}
{{- end }}
{{- if .global.Values.logLevelRoot }}
- name: OCTO_LOG_LEVEL_ROOT
  value: {{ .global.Values.logLevelRoot | quote }}
{{- end }}
{{- if eq .name "identity" -}}
{{- $name := "OCTO_IDENTITY" }}
{{ include "octo-mesh.system-env" . }}
{{ include "octo-mesh.broker-env" (dict "global" .global "name" $name) }}
{{ include "octo-mesh.blueprints-env" . }}
- name: OCTO_IDENTITY__KeyFilePath
  value: "/etc/octo-identity/IdentityServer4Auth.pfx"
- name: OCTO_IDENTITY__KEYFILEPASSWORD
  valueFrom:
    secretKeyRef:
        name: {{ printf "%s-backend" (include "octo-mesh.fullname" .global) }}
        key: identityKeyFile
- name: OCTO_IDENTITY__AUTHORITYURL
  value: {{ .global.Values.services.identity.publicUri }}
- name: OCTO_IDENTITY__INSTANCEPREFIX
  value: {{ .global.Values.serviceDefaults.instancePrefix }}
- name: OCTO_IDENTITY__IdentityServerLicenseKey
  value: {{ .global.Values.services.identity.identityServerLicenseKey }}
- name: OCTO_IDENTITY__AutoMapperLicenseKey
  value: {{ .global.Values.services.identity.autoMapperLicenseKey }}
{{- /* AB#5859 role check on the tenant REST API; Warn is the emergency exit. */}}
{{- $roleEnforcement := .global.Values.services.identity.apiRoleEnforcement | default "Enforce" }}
{{- if not (has $roleEnforcement (list "Enforce" "Warn")) }}
{{- fail (printf "services.identity.apiRoleEnforcement must be Enforce or Warn, got '%s'" $roleEnforcement) }}
{{- end }}
- name: OCTO_IDENTITYAPIAUTHORIZATION__ROLEENFORCEMENT
  value: {{ $roleEnforcement | quote }}
{{- if .global.Values.services.studio.publicUri }}
- name: OCTO_IDENTITY__RefineryStudioUrl
  value: {{ .global.Values.services.studio.publicUri }}
{{- end }}
{{- else if eq .name "assetRepository" -}}
{{- $name := "OCTO_ASSETREPOSITORY" }}
{{ include "octo-mesh.system-env" . }}
{{ include "octo-mesh.broker-env" (dict "global" .global "name" $name) }}
{{ include "octo-mesh.streamdata-env" (dict "global" .global "name" $name) }}
{{ include "octo-mesh.blueprints-env" . }}
- name: OCTO_ASSETREPOSITORY__AUTHORITY
  value: {{ .global.Values.services.identity.publicUri }}
- name: OCTO_ASSETREPOSITORY__PUBLICURL
  value: {{ .global.Values.services.assetRepository.publicUri }}
- name: OCTO_ASSETREPOSITORY__INSTANCEPREFIX
  value: {{ .global.Values.serviceDefaults.instancePrefix }}
{{- /*
AB#5139 lane-scoped catalogs. The private CK catalog
(PrivateOctoGitHub) and the private blueprint catalog
(PrivateOctoGitHubBlueprints) both default in the engine to the shared
main-lane repositories (construction-kit-libraries-build /
blueprint-libraries-build, branch main). A pre-release instance that runs
next to a main-lane instance therefore installs main-lane content. The
repository coordinates below let ONE installation redirect its private
catalogs at a lane-private repository.

Every coordinate is emitted ONLY when the value is non-empty: an empty
value is "keep the engine default", and an emitted-but-empty variable
would OVERRIDE that default with nothing (a catalog pointed at owner ""/
repo "" fails to refresh). So guard with `with` on each individual value
— never with `default`, which would materialise a value.

AB#6112: the GitHub blueprint catalogs have an IsEnabled switch since
engine AB#6112 (GitHubBlueprintCatalogOptions.IsEnabled, engine default
true). blueprintCatalog.privateGitHubEnabled is tri-state: empty keeps the
engine default (no env var), true/false is emitted explicitly. A plain
`with` cannot be used here because it skips `false`. Production sets it to
false so only released (public) blueprints are offered. Older engines
ignore the variable (it binds to nothing).
*/}}
{{- with .global.Values.services.assetRepository.ckCatalog }}
- name: OCTO_LocalFileSystemCatalog__IsEnabled
  value: "{{ .localFileSystemEnabled }}"
- name: OCTO_PrivateOctoGitHub__IsEnabled
  value: "{{ .privateGitHubEnabled }}"
{{- with .privateGitHub }}
{{- with .repositoryOwner }}
- name: OCTO_PrivateOctoGitHub__GitHubRepositoryOwner
  value: {{ . | quote }}
{{- end }}
{{- with .repositoryName }}
- name: OCTO_PrivateOctoGitHub__GitHubRepositoryName
  value: {{ . | quote }}
{{- end }}
{{- with .repositoryBranch }}
- name: OCTO_PrivateOctoGitHub__GitHubRepositoryBranch
  value: {{ . | quote }}
{{- end }}
{{- with .pagesUri }}
- name: OCTO_PrivateOctoGitHub__GitHubPagesUri
  value: {{ . | quote }}
{{- end }}
{{- end }}
{{- end }}
{{- with .global.Values.services.assetRepository.blueprintCatalog }}
{{- if ne (toString .privateGitHubEnabled) "" }}
- name: OCTO_PrivateOctoGitHubBlueprints__IsEnabled
  value: "{{ .privateGitHubEnabled }}"
{{- end }}
{{- with .privateGitHub }}
{{- with .repositoryOwner }}
- name: OCTO_PrivateOctoGitHubBlueprints__GitHubRepositoryOwner
  value: {{ . | quote }}
{{- end }}
{{- with .repositoryName }}
- name: OCTO_PrivateOctoGitHubBlueprints__GitHubRepositoryName
  value: {{ . | quote }}
{{- end }}
{{- with .repositoryBranch }}
- name: OCTO_PrivateOctoGitHubBlueprints__GitHubRepositoryBranch
  value: {{ . | quote }}
{{- end }}
{{- with .pagesUri }}
- name: OCTO_PrivateOctoGitHubBlueprints__GitHubPagesUri
  value: {{ . | quote }}
{{- end }}
{{- end }}
{{- end }}
{{- /*
AB#6174 file API limits (section "Files"). Numbers go through int64 so large
byte counts never render in float notation (1.048576e+08).
*/}}
{{- with .global.Values.services.assetRepository.files }}
- name: OCTO_Files__MaxUploadBytes
  value: {{ .maxUploadBytes | int64 | quote }}
- name: OCTO_Files__ZipMaxFiles
  value: {{ .zipMaxFiles | int64 | quote }}
- name: OCTO_Files__ZipMaxBytes
  value: {{ .zipMaxBytes | int64 | quote }}
- name: OCTO_Files__PreviewMaxBytes
  value: {{ .previewMaxBytes | int64 | quote }}
{{- end }}
{{- /*
AB#6175 migration sweep System.Reporting -> System.Files (section "FilesMigration"), off by default.
*/}}
{{- with .global.Values.services.assetRepository.filesMigration }}
- name: OCTO_FilesMigration__SweepEnabled
  value: {{ .sweepEnabled | default false | toString | quote }}
{{- end }}

{{- else if eq .name "bot" -}}
{{- $name := "OCTO_BOT" }}
{{ include "octo-mesh.system-env" . }}
{{ include "octo-mesh.broker-env" (dict "global" .global "name" $name) }}
{{ include "octo-mesh.streamdata-env" (dict "global" .global "name" $name) }}
- name: OCTO_BOT__AUTHORITYURL
  value: {{ .global.Values.services.identity.publicUri }}
- name: OCTO_BOT__PUBLICURL
  value: {{ .global.Values.services.bot.publicUri }}
{{- if .global.Values.services.studio.publicUri }}
- name: OCTO_BOT__PUBLICREFINERYSTUDIOURL
  value: {{ .global.Values.services.studio.publicUri }}
{{- end }}
- name: OCTO_BOT__INSTANCEPREFIX
  value: {{ .global.Values.serviceDefaults.instancePrefix }}
{{- /* AB#5560 PVC / artifact store; renders nothing with the defaults. */}}
{{- include "octo-mesh.bot-storage-env" . }}

{{- else if eq .name "communication" -}}
{{- $name := "OCTO_COMMUNICATIONCONTROLLER" }}
{{ include "octo-mesh.system-env" . }}
{{ include "octo-mesh.broker-env" (dict "global" .global "name" $name) }}
{{ include "octo-mesh.blueprints-env" . }}
- name: OCTO_COMMUNICATIONCONTROLLER__AUTHORITYURL
  value: {{ .global.Values.services.identity.publicUri }}
- name: OCTO_COMMUNICATIONCONTROLLER__PUBLICURL
  value: {{ .global.Values.services.communication.publicUri }}
- name: OCTO_COMMUNICATIONCONTROLLER__INSTANCEPREFIX
  value: {{ .global.Values.serviceDefaults.instancePrefix }}
{{- /*
AB#4923 HTTP activator. Only half of the wiring lives here: what actually routes
traffic is the adapter Ingress annotation
nginx.ingress.kubernetes.io/default-backend, which the communication operator
projects onto every workload (OPERATOR__INGRESS__ANNOTATIONS__n__*) and which
must name this service. Enabling the flag without that annotation is inert.
*/}}
{{- if .global.Values.services.communication.activatorEnabled }}
- name: OCTO_COMMUNICATIONCONTROLLER__ACTIVATORENABLED
  value: "true"
{{- end }}
{{- /*
AB#5063 / AB#5059 (AB#5528 phase 3): staged authorization of the two SignalR hubs.
Rendered always, so the mode in effect is visible on the deployment. Section names
are the controller's AdapterHubAuthorizationOptions.SectionName /
OperatorHubAuthorizationOptions.SectionName; the OCTO_ prefix is stripped by the
controller's AddEnvironmentVariables("OCTO_"). LogOnly changes no outcome; Enforce
refuses unauthenticated / wrongly scoped (adapter hub: wrong-tenant) connections.
Any other value fails the render - a typo must not silently fall back to LogOnly.
*/}}
{{- $hubAuthz := .global.Values.services.communication.hubAuthorization | default dict }}
{{- $adapterHubMode := $hubAuthz.adapterMode | default "LogOnly" }}
{{- if not (has $adapterHubMode (list "LogOnly" "Enforce")) }}
{{- fail (printf "services.communication.hubAuthorization.adapterMode must be LogOnly or Enforce, got '%v'" $adapterHubMode) }}
{{- end }}
{{- $operatorHubMode := $hubAuthz.operatorMode | default "LogOnly" }}
{{- if not (has $operatorHubMode (list "LogOnly" "Enforce")) }}
{{- fail (printf "services.communication.hubAuthorization.operatorMode must be LogOnly or Enforce, got '%v'" $operatorHubMode) }}
{{- end }}
- name: OCTO_ADAPTERHUBAUTHORIZATION__MODE
  value: {{ $adapterHubMode | quote }}
- name: OCTO_OPERATORHUBAUTHORIZATION__MODE
  value: {{ $operatorHubMode | quote }}
{{- /*
AES-256-GCM master key for IWorkloadEncryptionService. Emitted only when
secrets.communicationInstanceSecretKey is set so unconfigured clusters
keep starting (CommunicationControllerOptions doc: empty is tolerated at
startup, every encrypt/decrypt call then throws a clear config error).
Provisioned per cluster via Vault — see octo-mesh-deployment/docs/VAULT-SETUP.md.
*/}}
{{- if .global.Values.secrets.communicationInstanceSecretKey }}
- name: OCTO_COMMUNICATIONCONTROLLER__INSTANCESECRETKEY
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh.fullname" .global) }}
      key: communicationInstanceSecretKey
{{- end }}
{{- /*
Named public base domains. Each entry in services.communication.domains is
projected as OCTO_COMMUNICATIONCONTROLLER__DOMAINS__<KEY>; .NET configuration
binding turns it back into a Dictionary<string,string> on
CommunicationControllerOptions.Domains. KEY is uppercased so the rendered env
var matches the .NET binding convention; the resolver itself is
case-insensitive on lookup so blueprint authors can still write
{{domain.default}} in lowercase.
*/}}
{{- range $key, $value := .global.Values.services.communication.domains }}
- name: OCTO_COMMUNICATIONCONTROLLER__DOMAINS__{{ upper $key }}
  value: {{ $value | quote }}
{{- end }}
{{- /*
Named public service URIs surfaced as {{service.NAME}} placeholders in
workload Hostname / ValueOverride.Value / ValuesYaml. The semantic key
"authority" maps to the Identity Service publicUri; other keys mirror the
helm-section name. .NET configuration binding turns OCTO_…__SERVICEURLS__<KEY>
back into a Dictionary<string,string> on CommunicationControllerOptions.ServiceUrls.
Lookup is case-insensitive so blueprint authors can write {{service.authority}}
in lowercase regardless of env-var casing.
*/}}
- name: OCTO_COMMUNICATIONCONTROLLER__SERVICEURLS__AUTHORITY
  value: {{ .global.Values.services.identity.publicUri | quote }}
- name: OCTO_COMMUNICATIONCONTROLLER__SERVICEURLS__ASSETREPOSITORY
  value: {{ .global.Values.services.assetRepository.publicUri | quote }}
- name: OCTO_COMMUNICATIONCONTROLLER__SERVICEURLS__BOT
  value: {{ .global.Values.services.bot.publicUri | quote }}
- name: OCTO_COMMUNICATIONCONTROLLER__SERVICEURLS__COMMUNICATION
  value: {{ .global.Values.services.communication.publicUri | quote }}
{{- if .global.Values.services.studio.publicUri }}
- name: OCTO_COMMUNICATIONCONTROLLER__SERVICEURLS__STUDIO
  value: {{ .global.Values.services.studio.publicUri | quote }}
{{- end }}
{{- else if eq .name "platformServices" -}}
{{- $name := "OCTO_PLATFORMSERVICES" }}
{{- /*
Phase 4 of the platform-services initiative — platform-services now OWNS the
System.UI CK model + the System.UI.* / System.TenantMode service-managed
blueprints (moved from admin-panel). It therefore needs three pieces of env
(it used to need only MongoDB for the Phase-2 observability API):
  - system-env (MongoDB): observability API + blueprint apply.
  - broker-env: it runs the distribution-event-hub tenant-lifecycle host
    (PosCreateTenant / PosUpdateTenant) to seed the blueprints on tenant
    create / attach / restore. Its UniqueServiceAddress is "PlatformServices",
    distinct from admin-panel's, so the exclusive queues never collide while
    both are deployed during the sunset window.
  - blueprints-env: ${octo.environment(Mode)} / ${octo.isSystemTenant} drive
    the cockpit `requires:` gates and the TenantMode seed.
*/}}
{{ include "octo-mesh.system-env" . }}
{{ include "octo-mesh.broker-env" (dict "global" .global "name" $name) }}
{{ include "octo-mesh.blueprints-env" . }}
- name: OCTO_PLATFORMSERVICES__INSTANCEPREFIX
  value: {{ .global.Values.serviceDefaults.instancePrefix }}
- name: OCTO_PLATFORMSERVICES__CRATEDBADMINURL
  value: {{ .global.Values.externalUris.crateDb }}
- name: OCTO_PLATFORMSERVICES__GRAFANAURL
  value: {{ .global.Values.externalUris.grafana }}
- name: OCTO_PLATFORMSERVICES__MESHADAPTERURL
  value: {{ .global.Values.externalUris.meshAdapter }}
- name: OCTO_PLATFORMSERVICES__AISERVICESURL
  value: {{ .global.Values.services.aiServices.publicUri }}
- name: OCTO_PLATFORMSERVICES__ASSETSERVICEURL
  value: {{ .global.Values.services.assetRepository.publicUri }}
- name: OCTO_PLATFORMSERVICES__BOTSERVICEURL
  value: {{ .global.Values.services.bot.publicUri }}
- name: OCTO_PLATFORMSERVICES__COMMUNICATIONSERVICEURL
  value: {{ .global.Values.services.communication.publicUri }}
{{- /*
McpServiceUrl feeds the `mcpServices` _configuration field (Studio's
Development→Swagger→McpServices link). The MCP service ships in its own
chart, so the core value tree has no services.mcp block — an explicit
externalUris.mcp wins, otherwise the URL is composed as
<scheme>://mcp.<domain> with the same scheme/domain resolution as
blueprints-env, matching ${octo.mcp.publicUrl} and the mcp.<domain> host
convention on all clusters.
*/}}
{{- $mcpIdentityUrl := urlParse (default "" .global.Values.services.identity.publicUri) }}
{{- $mcpDerivedDomain := "" }}
{{- if $mcpIdentityUrl.host }}
{{- $mcpDerivedDomain = (splitList "." $mcpIdentityUrl.host) | rest | join "." }}
{{- end }}
{{- $mcpScheme := .global.Values.serviceDefaults.scheme | default ($mcpIdentityUrl.scheme | default "https") }}
{{- $mcpDomain := .global.Values.serviceDefaults.domain | default $mcpDerivedDomain }}
{{- $mcpUrl := .global.Values.externalUris.mcp | default (ternary (printf "%s://mcp.%s" $mcpScheme $mcpDomain) "" (ne $mcpDomain "")) }}
{{- if $mcpUrl }}
- name: OCTO_PLATFORMSERVICES__MCPSERVICEURL
  value: {{ $mcpUrl | quote }}
{{- end }}
{{- /*
Reporting ships in helm-pro (octo-mesh-reporting chart), so the core value
tree has no services.reporting block — the public URL is announced via
externalUris.reporting, like the other separately-deployed endpoints above.
Emitted unconditionally: an empty value makes platform-services serve an
empty `reportingServices` _configuration field, which consumers read as
"service not part of this installation" (AB#4884). The Tenant Features panel
in Refinery Studio keys its Reporting row on this.
*/}}
- name: OCTO_PLATFORMSERVICES__REPORTINGSERVICEURL
  value: {{ .global.Values.externalUris.reporting | quote }}
- name: OCTO_PLATFORMSERVICES__AUTHORITYURL
  value: {{ .global.Values.services.identity.publicUri }}
{{- /*
ADMINPANELURL is no longer wired: Phase 4 dropped the redirectUri /
postLogoutRedirectUri fields (and the AdminPanelUrl option) from the
_configuration DTO, so platform-services no longer needs the admin-panel URL.
*/}}
{{- /*
SYSTEMTENANTID is intentionally NOT sourced from serviceDefaults.systemDatabaseName
here: the DB name is PascalCase ("OctoSystem") but external consumers
(Refinery Studio, Office, PowerBI) read this field as the lowercase
tenant-id path segment (e.g. /octosystem/_configuration) — the URL is
case-sensitive in the ASP.NET routing on the consumer side. The legacy
admin-panel never overrode this from helm either; both services rely on
the lowercase "octosystem" appsettings default.
*/}}

{{- else if eq .name "studio" -}}
{{- $name := "OCTO_REFINERY_STUDIO" }}
{{- /*
The studio Docker entrypoint templates BOTH `platformUri` (new) and `adminUri`
(legacy) into /assets/config.json from the env vars below. The configuration
loader (AppConfigurationService) prefers `platformUri`; `adminUri` is kept only
so studio builds / Office add-ins / PowerBI connectors baked against the old
field name keep resolving. Both now point at platform-services — admin-panel was
retired in Phase 4, so there is no admin-panel fallback any more.
*/}}
{{- $configEndpointUri := .global.Values.services.platformServices.publicUri }}
- name: PLATFORM_URI
  value: {{ $configEndpointUri }}
- name: ADMIN_PANEL_URI
  value: {{ $configEndpointUri }}
- name: APP_URI
  value: {{ .global.Values.services.studio.publicUri }}
{{- /*
Dash0 OpenTelemetry (browser RUM). Per-environment opt-in: only emitted when an
endpoint is configured, so environments without Dash0 activated get no DASH0_*
vars and the studio's telemetry init stays a no-op. The entrypoint templates
these into /assets/config.json; the auth token is a secret (secretKeyRef), the
endpoint/dataset/environment are non-secret plain values.
*/}}
{{- if .global.Values.services.studio.dash0.endpoint }}
- name: DASH0_ENDPOINT
  value: {{ .global.Values.services.studio.dash0.endpoint | quote }}
- name: DASH0_DATASET
  value: {{ .global.Values.services.studio.dash0.dataset | default "" | quote }}
- name: DASH0_ENVIRONMENT
  value: {{ .global.Values.services.studio.dash0.environment | default "" | quote }}
- name: DASH0_AUTH_TOKEN
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh.fullname" .global) }}
      key: dash0WebAuthToken
{{- end }}
{{- else if eq .name "aiServices" -}}
{{- $name := "OCTO_AISERVICES" }}
{{ include "octo-mesh.system-env" . }}
{{ include "octo-mesh.broker-env" (dict "global" .global "name" $name) }}
{{ include "octo-mesh.blueprints-env" . }}
- name: OCTO_AISERVICES__AUTHORITY
  value: {{ .global.Values.services.identity.publicUri }}
- name: OCTO_AISERVICES__PUBLICURL
  value: {{ .global.Values.services.aiServices.publicUri }}
{{- else }}
{{- fail (printf "Service %s is not configured for the octo-mesh helm chart." .name) -}}
{{- end }}
{{- end }}