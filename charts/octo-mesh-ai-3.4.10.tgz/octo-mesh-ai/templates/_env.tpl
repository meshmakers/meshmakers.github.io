{{- define "octo-mesh.system-env" -}}
- name: OCTO_SYSTEM__SYSTEMDATABASENAME
  value: {{ .Values.global.systemDatabaseName }}
- name: OCTO_SYSTEM__DATABASEHOST
  value: {{ .Values.global.clusterDependencies.mongodbHost }}
- name: OCTO_SYSTEM__DATABASEUSERPASSWORD
  valueFrom:
    secretKeyRef:
        name: {{ printf "%s-backend" (include "octo-mesh-ai.fullname" .) }}
        key: databaseUser
- name: OCTO_SYSTEM__ADMINUSERPASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh-ai.fullname" .) }}
      key: databaseAdmin
{{- end -}}

{{- define "octo-mesh.broker-env" -}}
- name: {{ printf "%s__BROKERHOST" (upper .name) }}
  value: {{ .global.Values.global.clusterDependencies.rabbitMqHost }}
- name: {{ printf "%s__BROKERUSER" (upper .name) }}
  value: {{ .global.Values.global.clusterDependencies.rabbitMqUser }}
- name: {{ printf "%s__BROKERPASSWORD" (upper .name) }}
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh-ai.fullname" .global) }}
      key: rabbitmq
{{- end -}}

{{- define "octo-mesh.streamdata-env" -}}
# Instance-level kill switch for StreamData. Read by
# StreamDataInstanceConfiguration (root "StreamData" config section, hence
# the fixed env-var name without a service prefix). Defaults to false so
# the feature is opt-in per cluster.
- name: OCTO_STREAMDATA__ENABLED
  value: {{ .global.Values.global.clusterDependencies.streamDataEnabled | quote }}
- name: {{ printf "%s__STREAMDATAHOST" (upper .name) }}
  value: {{ .global.Values.global.clusterDependencies.streamDataHost }}
- name: {{ printf "%s__STREAMDATAUSER" (upper .name) }}
  value: {{ .global.Values.global.clusterDependencies.streamDataUser }}
- name: {{ printf "%s__STREAMDATAPASSWORD" (upper .name) }}
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh-ai.fullname" .global) }}
      key: streamDataPassword
{{- end -}}

{{- define "octo-mesh-ai.env" -}}
{{- $name := "OCTO_AI" }}
{{- include "octo-mesh.system-env" . }}
{{ include "octo-mesh.broker-env" (dict "global" . "name" $name) }}
{{ include "octo-mesh.streamdata-env" (dict "global" . "name" $name) }}
- name: OCTO_AI__AUTHORITYURL
  value: {{ .Values.global.authUri }}
- name: OCTO_AI__ASSETSERVICESURL
  value: {{ .Values.global.assetRepositoryUri }}
- name: OCTO_AI__PUBLICURL
  value: {{ .Values.ai.publicUri }}
- name: OCTO_AI__AnthropicApiKey
  value: {{ .Values.ai.anthropic.anthropicApiKey }}
- name: OCTO_AI__AnthropicModel
  value: {{ .Values.ai.anthropic.anthropicModel }}
- name: OCTO_AI__MaxTokens
  value: {{ .Values.ai.anthropic.maxTokens | quote }}
- name: OCTO_AI__Temperature
  value: {{ .Values.ai.anthropic.temperature | quote }}
- name: OCTO_AI__INSTANCEPREFIX
  value: {{ .Values.global.instancePrefix }}
- name: OCTO_AI__OCTOMESHMCPSERVICEURL
  value: {{ .Values.global.octoMeshMcpServiceUrl }}
{{- /*
URL the adapter writes into every per-session .mcp.json (AgentWorkspaceMaterializer.
BuildMcpConfigJson). Must point at the chart's own in-cluster MCP Service — the code
default `http://octo-ai-mcp:8080/mcp` does not match the chart-prefixed Service name
(`{release}-mcp`) so without this override claude renders an unresolvable host in the
workspace .mcp.json and every MCP tool call fails with a DNS error. Public HTTPS
endpoints can't be used here because the worker container's CA bundle does not carry
the mm.cloud root cert; the in-cluster http:// path bypasses TLS entirely.
*/}}
{{- /*
Post-chart-split (2026-06-13): octo-mesh-mcp ships as a separate chart, so
the AI chart no longer infers the in-cluster MCP URL from its own values.
Tenant configures `ai.workspace.mcpServerUrl` explicitly — typically
`http://<mcp-release-name>-mcp:<port>/mcp` for an in-cluster octo-mesh-mcp
deployment. Empty leaves the env var unset and the adapter falls back to
the (broken) code default `http://octo-ai-mcp:8080/mcp`, which is the
documented signal that MCP integration isn't wired.
*/}}
{{- if .Values.ai.workspace.mcpServerUrl }}
- name: OCTO_AIWORKSPACE__MCPSERVERURL
  value: {{ .Values.ai.workspace.mcpServerUrl | quote }}
{{- end }}
{{- /*
M3 B-2d: the URL pattern the adapter's PreviewUrlBuilder substitutes
{tenant} + {session} into before rendering the ## Preview block in the
Application JobKind CLAUDE.md. Empty leaves the adapter rendering an
empty preview section (the briefing's workflow step 5 only fires when
the block is present). When `worker.previewIngress.enabled=true` is set,
this should match the chart's tenant subdomain layout, e.g.
`https://{tenant}.preview.test-2.mm.cloud/{session}/`.
*/}}
{{- if .Values.ai.workspace.previewUrlPattern }}
- name: OCTO_AIWORKSPACE__PREVIEWURLPATTERN
  value: {{ .Values.ai.workspace.previewUrlPattern | quote }}
{{- end }}
{{- /*
Bug C fix (chart 0.8.0): ClientCredentials OAuth client the adapter uses to mint a
tenant-scoped access token for the in-cluster MCP server. Both env vars must be set or both
empty — partial config (e.g. clientId without clientSecret) is the same as no config and the
adapter writes an unauthenticated .mcp.json.
*/}}
{{- if and .Values.ai.oauth.clientId .Values.ai.oauth.clientSecret }}
- name: OCTO_AIMCPAUTH__CLIENTID
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh-ai.fullname" .) }}
      key: aiMcpAuthClientId
- name: OCTO_AIMCPAUTH__CLIENTSECRET
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh-ai.fullname" .) }}
      key: aiMcpAuthClientSecret
{{- end }}
{{- /*
AES-256-GCM master key for the adapter's InstanceSecretEncryptionService
(implementation-m1.md §3.5). Emitted only when secrets.aiInstanceSecretKey is
set so unconfigured clusters keep starting (AiEncryptionOptions doc: empty is
tolerated at startup, every encrypt/decrypt call then throws a clear config
error). The byte value must match secrets.communicationInstanceSecretKey in
the octo-mesh chart for cross-replica decrypt to work — operator sets both
to the same Vault-provisioned value (deferred env-var unify task #18 will
collapse this into a single global key).
*/}}
{{- if .Values.global.secrets.aiInstanceSecretKey }}
- name: OCTO_AIENCRYPTION__INSTANCESECRETKEY
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh-ai.fullname" .) }}
      key: aiInstanceSecretKey
{{- end }}
{{- /*
Chart 0.9.0 (M2 carry-over): proactive Anthropic OAuth token-refresh worker.
Without it the per-tenant Anthropic lease access token silently expires after
8h and every session started past that point fails with HTTP 401 until an
operator re-registers from a local Mac keychain. With enabled=true the adapter
ticks every IntervalSeconds and refreshes any lease whose AccessExpiresAt is
within RefreshIfExpiresInSeconds of now. OAuthEndpoint + OAuthClientId are
Anthropic's public Claude Code coordinates — not secret, no Vault round-trip
needed; override only if Anthropic moves the endpoint.
*/}}
{{- if .Values.ai.tokenRefresh.enabled }}
- name: OCTO_AITOKENREFRESH__ENABLED
  value: "true"
- name: OCTO_AITOKENREFRESH__OAUTHENDPOINT
  value: {{ .Values.ai.tokenRefresh.oauthEndpoint | quote }}
- name: OCTO_AITOKENREFRESH__OAUTHCLIENTID
  value: {{ .Values.ai.tokenRefresh.oauthClientId | quote }}
- name: OCTO_AITOKENREFRESH__INTERVALSECONDS
  value: {{ .Values.ai.tokenRefresh.intervalSeconds | quote }}
- name: OCTO_AITOKENREFRESH__REFRESHIFEXPIRESINSECONDS
  value: {{ .Values.ai.tokenRefresh.refreshIfExpiresInSeconds | quote }}
{{- end }}
{{- if .Values.worker.enabled }}
# #4130 Phase C: flip the orchestrator to Mode=Remote and point it at the
# per-tenant worker Service. RemoteAgentWorkerClient substitutes `{tenant}`
# at runtime with the session's tenant id, so a single env var routes every
# tenant to its own pod.
- name: OCTO_AIWORKER__MODE
  value: "Remote"
- name: OCTO_AIWORKER__REMOTEWORKERURL
  value: {{ printf "http://%s-worker-{tenant}:%d/internal/worker/run" (include "octo-mesh-ai.fullname" .) (int .Values.worker.service.port) | quote }}
{{- end }}
{{- end -}}

