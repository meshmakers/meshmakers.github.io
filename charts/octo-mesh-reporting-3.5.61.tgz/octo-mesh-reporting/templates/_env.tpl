{{- define "octo-mesh.system-env" -}}
- name: OCTO_SYSTEM__DATABASEHOST
  value: {{ .Values.clusterDependencies.mongodbHost }}
- name: OCTO_SYSTEM__DATABASEUSERPASSWORD
  valueFrom:
    secretKeyRef:
        name: {{ printf "%s-backend" (include "octo-mesh-reporting.fullname" .) }}
        key: databaseUser
- name: OCTO_SYSTEM__ADMINUSERPASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh-reporting.fullname" .) }}
      key: databaseAdmin
{{- /*
SECRET attribute key ring (AB#5536): part of system-env because this service
hosts the runtime engine (AddRuntimeEngine binds SecretEncryption:*). Same block
as octo-helm-core/src/octo-mesh/templates/_env.tpl.
*/}}
{{- include "octo-mesh.secretEncryption-env" (dict "ring" (fromJson (include "octo-mesh-reporting.secretEncryptionRing" .)) "secretName" (printf "%s-backend" (include "octo-mesh-reporting.fullname" .))) }}
{{- end }}

{{- define "octo-mesh.broker-env" -}}
- name: {{ printf "%s__BROKERHOST" (upper .name) }}
  value: {{ .global.Values.clusterDependencies.rabbitMqHost }}
- name: {{ printf "%s__BROKERUSER" (upper .name) }}
  value: {{ .global.Values.clusterDependencies.rabbitMqUser }}
- name: {{ printf "%s__BROKERPASSWORD" (upper .name) }}
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh-reporting.fullname" .global) }}
      key: rabbitmq     
{{- end }}

{{- define "octo-mesh.streamdata-env" -}}
# Instance-level kill switch for StreamData. Read by
# StreamDataInstanceConfiguration (root "StreamData" config section, hence
# the fixed env-var name without a service prefix). Defaults to false so
# the feature is opt-in per cluster.
- name: OCTO_STREAMDATA__ENABLED
  value: {{ .global.Values.clusterDependencies.streamDataEnabled | quote }}
- name: {{ printf "%s__STREAMDATAHOST" (upper .name) }}
  value: {{ .global.Values.clusterDependencies.streamDataHost }}
- name: {{ printf "%s__STREAMDATAUSER" (upper .name) }}
  value: {{ .global.Values.clusterDependencies.streamDataUser }}
- name: {{ printf "%s__STREAMDATAPASSWORD" (upper .name) }}
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh-reporting.fullname" .global) }}
      key: streamDataPassword
{{- end }}


{{- define "octo-mesh.env" -}}
{{- $name := "OCTO_REPORTING" }}
{{- /*
  AB#5478 §2.1 — one service.name per process. The pod label
  app.kubernetes.io/name is already the chart name here, so traces and logs were
  right; the in-process SDK fell back to the entry assembly name without
  OTEL_SERVICE_NAME, which put this service's custom metrics into a separate Dash0
  entity (Meshmakers.Octo.Backend.ReportingServices) from its own spans. Value
  matches the label on purpose. Same block as in the mcp and ai charts.
*/}}
- name: OTEL_SERVICE_NAME
  value: {{ include "octo-mesh-reporting.name" . | quote }}
{{- /*
  Our own ActivitySources, declared to the injected auto-instrumentation: this
  service hosts the StreamData engine and the in-process TracerProvider carries no
  exporter by design. Mirrors octo-helm-core/src/octo-mesh/templates/_env.tpl.
*/}}
- name: OTEL_DOTNET_AUTO_TRACES_ADDITIONAL_SOURCES
  value: "Meshmakers.Octo.StreamData,Meshmakers.Octo.StreamData.Crate"
{{ include "octo-mesh.system-env" . }}
{{ include "octo-mesh.broker-env" (dict "global" . "name" $name) }} 
{{ include "octo-mesh.streamdata-env" (dict "global" . "name" $name) }}
- name: OCTO_REPORTING__AUTHORITYURL
  value: {{ .Values.authUri }}
- name: OCTO_REPORTING__PUBLICURL
  value: {{ .Values.publicUri }}
- name: OCTO_REPORTING__INSTANCEPREFIX
  value: {{ .Values.instancePrefix }}
{{- /*
  AB#7581: mode of the report generation route lock. Rendered explicitly so the mode in effect is
  visible on the deployment; a typo must not silently fall back to LogOnly.
*/}}
{{- $reportGenerationAuthorization := .Values.reportGenerationAuthorization | default "LogOnly" }}
{{- if not (has $reportGenerationAuthorization (list "LogOnly" "Enforce")) }}
{{- fail (printf "reportGenerationAuthorization must be LogOnly or Enforce, got '%v'" $reportGenerationAuthorization) }}
{{- end }}
- name: OCTO_REPORTING__REPORTGENERATIONAUTHORIZATION
  value: {{ $reportGenerationAuthorization | quote }}
{{- /*
  AB#8011: mode of the viewer/designer REST route lock (Telerik services behind the viewer and designer pages).
  Separate from reportGenerationAuthorization: different callers, flipped independently per cluster.
*/}}
{{- $reportServiceAuthorization := .Values.reportServiceAuthorization | default "LogOnly" }}
{{- if not (has $reportServiceAuthorization (list "LogOnly" "Enforce")) }}
{{- fail (printf "reportServiceAuthorization must be LogOnly or Enforce, got '%v'" $reportServiceAuthorization) }}
{{- end }}
- name: OCTO_REPORTING__REPORTSERVICEAUTHORIZATION
  value: {{ $reportServiceAuthorization | quote }}
{{- end }}