{{/*
Expand the name of the chart.
*/}}
{{- define "octo-mesh-reporting.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "octo-mesh-reporting.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "octo-mesh-reporting.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "octo-mesh-reporting.labels" -}}
helm.sh/chart: {{ include "octo-mesh-reporting.chart" . }}
{{ include "octo-mesh-reporting.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "octo-mesh-reporting.selectorLabels" -}}
app.kubernetes.io/name: {{ include "octo-mesh-reporting.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "octo-mesh-reporting.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "octo-mesh-reporting.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Check if a mandadory value exists
*/}}
{{- define "checkMandatoryValue" -}}
{{- if not .value -}}
{{- fail (printf "Value %s does not exist. Please define a corresponding value." .name) -}}
{{- end -}}
{{- end -}}

{{/*
SECRET attribute key ring (AB#5536, concept AB#5528 §3.5, decision 3).
Mirrors "octo-mesh.secretEncryption" in octo-helm-core/src/octo-mesh — keep the
two in step.

Call with (dict "secrets" <secrets map> "path" "<values path for messages>"
"fallbackInstanceKey" <optional>) and read the result with fromJson:
  { "keys": {kid: base64Key}, "activeKeyId": "k1", "legacyV1Key": base64Key }

Default (no override map): the instance secret (communicationInstanceSecretKey,
the same value the octo-mesh chart carries) IS key `k1` and the legacy `enc:v1`
key, and `k1` is active. No new required value: without an instance secret the
ring is empty and the chart emits nothing — the service starts and only SECRET
attribute access fails with a configuration error.

Rotation override: a non-empty secretEncryptionKeys REPLACES the derived ring
(list k1 again while it is still needed) and secretEncryptionActiveKeyId picks
the active key. LegacyV1Key always stays the instance secret.

Key ids: 1-32 lowercase letters/digits — the id is part of an env var name, a
Secret key and the `enc:v2:<kid>:` header, and keeps its case in the env var.
*/}}
{{- define "octo-mesh.secretEncryption" -}}
{{- $s := .secrets | default dict -}}
{{- $path := .path -}}
{{- $instanceKey := $s.communicationInstanceSecretKey | default .fallbackInstanceKey | default "" -}}
{{- $keys := dict -}}
{{- $override := $s.secretEncryptionKeys | default dict -}}
{{- if $override -}}
{{- range $kid, $value := $override -}}
{{- if not (regexMatch "^[a-z0-9]{1,32}$" $kid) -}}
{{- fail (printf "%s.secretEncryptionKeys: key id '%s' must be 1-32 lowercase letters or digits" $path $kid) -}}
{{- end -}}
{{- if not $value -}}
{{- fail (printf "%s.secretEncryptionKeys.%s is empty; remove the entry instead" $path $kid) -}}
{{- end -}}
{{- if ne (len (b64dec $value)) 32 -}}
{{- fail (printf "%s.secretEncryptionKeys.%s must be a base64-encoded 32-byte key (openssl rand -base64 32)" $path $kid) -}}
{{- end -}}
{{- $_ := set $keys $kid $value -}}
{{- end -}}
{{- else if $instanceKey -}}
{{- $_ := set $keys "k1" $instanceKey -}}
{{- end -}}
{{- $active := "" -}}
{{- if $keys -}}
{{- $active = $s.secretEncryptionActiveKeyId | default "k1" -}}
{{- if not (hasKey $keys $active) -}}
{{- fail (printf "%s.secretEncryptionActiveKeyId '%s' is not a key id of the SECRET key ring (%s)" $path $active (keys $keys | sortAlpha | join ", ")) -}}
{{- end -}}
{{- end -}}
{{- /*
Missing-key guard (AB#5528 phase 3), opt-in via <path>.secretEncryptionRequired
(default false = unchanged: an empty ring renders nothing). Same rules as
"octo-mesh.secretEncryptionRequiredCheck" in octo-helm-core/src/octo-mesh:
fail when the ring is empty or the instance secret is not a base64 32-byte key
(catches an unresolved "$(VAULT_instance_secret_key)" macro). With a fallback
key (AI chart: aiInstanceSecretKey) it also fails when both values are set and
differ — they must be the same cluster instance secret (charts without a
fallback never hit that branch; it stays for "keep in step" parity). Only
true / "true" enables it; any other value than true/false fails rendering.
The instance secret is trimmed before the checks, like the engine does.
*/}}
{{- if not (has (toString $s.secretEncryptionRequired) (list "true" "false" "<nil>" "")) -}}
{{- fail (printf "%s.secretEncryptionRequired must be true or false, got '%v'" $path $s.secretEncryptionRequired) -}}
{{- end -}}
{{- if eq (toString $s.secretEncryptionRequired) "true" -}}
{{- if not $keys -}}
{{- fail (printf "%s.secretEncryptionRequired is true but the SECRET key ring is empty: set %s.communicationInstanceSecretKey (Vault instance_secret_key, base64 32 bytes) or %s.secretEncryptionKeys" $path $path $path) -}}
{{- end -}}
{{- if and $instanceKey (ne (len (b64dec (trim $instanceKey))) 32) -}}
{{- fail (printf "%s.communicationInstanceSecretKey must be a base64-encoded 32-byte key (openssl rand -base64 32) when %s.secretEncryptionRequired is true; a value like $(VAULT_instance_secret_key) means the Vault key is missing for this cluster" $path $path) -}}
{{- end -}}
{{- if and $s.communicationInstanceSecretKey .fallbackInstanceKey (ne (trim $s.communicationInstanceSecretKey) (trim .fallbackInstanceKey)) -}}
{{- fail (printf "%s.communicationInstanceSecretKey and the fallback instance secret (aiInstanceSecretKey) differ; both must be the cluster's Vault instance_secret_key" $path) -}}
{{- end -}}
{{- end -}}
{{- toJson (dict "keys" $keys "activeKeyId" $active "legacyV1Key" $instanceKey) -}}
{{- end -}}

{{/*
Env block for the SECRET key ring (AB#5536), bound by the engine in
AddRuntimeEngine() as SecretEncryption:Keys:<kid> / :ActiveKeyId / :LegacyV1Key.
Call with (dict "ring" <ring dict> "secretName" "<release>-backend").
*/}}
{{- define "octo-mesh.secretEncryption-env" -}}
{{- $secretName := .secretName }}
{{- range $kid, $_ := .ring.keys }}
- name: OCTO_SECRETENCRYPTION__KEYS__{{ $kid }}
  valueFrom:
    secretKeyRef:
      name: {{ $secretName }}
      key: {{ printf "secretEncryptionKey-%s" $kid }}
{{- end }}
{{- if .ring.keys }}
- name: OCTO_SECRETENCRYPTION__ACTIVEKEYID
  value: {{ .ring.activeKeyId | quote }}
{{- end }}
{{- if .ring.legacyV1Key }}
- name: OCTO_SECRETENCRYPTION__LEGACYV1KEY
  valueFrom:
    secretKeyRef:
      name: {{ $secretName }}
      key: communicationInstanceSecretKey
{{- end }}
{{- end -}}

{{/* Effective SECRET key ring of this chart (AB#5536), as JSON. */}}
{{- define "octo-mesh-reporting.secretEncryptionRing" -}}
{{- include "octo-mesh.secretEncryption" (dict "secrets" .Values.secrets "path" "secrets") -}}
{{- end -}}
