{{- define "octo-mesh.system-env" -}}
- name: OCTO_SYSTEM__SYSTEMDATABASENAME
  value: {{ .Values.global.systemDatabaseName }}
- name: OCTO_SYSTEM__DATABASEHOST
  value: {{ .Values.global.clusterDependencies.mongodbHost }}
- name: OCTO_SYSTEM__DATABASEUSERPASSWORD
  valueFrom:
    secretKeyRef:
        name: {{ printf "%s-backend" (include "octo-mesh-ai.fullname" .) }}
        key: databaseUser
- name: OCTO_SYSTEM__ADMINUSERPASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh-ai.fullname" .) }}
      key: databaseAdmin
{{- end -}}

{{- define "octo-mesh.broker-env" -}}
- name: {{ printf "%s__BROKERHOST" (upper .name) }}
  value: {{ .global.Values.global.clusterDependencies.rabbitMqHost }}
- name: {{ printf "%s__BROKERUSER" (upper .name) }}
  value: {{ .global.Values.global.clusterDependencies.rabbitMqUser }}
- name: {{ printf "%s__BROKERPASSWORD" (upper .name) }}
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh-ai.fullname" .global) }}
      key: rabbitmq
{{- end -}}

{{- define "octo-mesh.streamdata-env" -}}
# Instance-level kill switch for StreamData. Read by
# StreamDataInstanceConfiguration (root "StreamData" config section, hence
# the fixed env-var name without a service prefix). Defaults to false so
# the feature is opt-in per cluster.
- name: OCTO_STREAMDATA__ENABLED
  value: {{ .global.Values.global.clusterDependencies.streamDataEnabled | quote }}
- name: {{ printf "%s__STREAMDATAHOST" (upper .name) }}
  value: {{ .global.Values.global.clusterDependencies.streamDataHost }}
- name: {{ printf "%s__STREAMDATAUSER" (upper .name) }}
  value: {{ .global.Values.global.clusterDependencies.streamDataUser }}
- name: {{ printf "%s__STREAMDATAPASSWORD" (upper .name) }}
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "octo-mesh-ai.fullname" .global) }}
      key: streamDataPassword
{{- end -}}

{{- define "octo-mesh-ai.env" -}}
{{- $name := "OCTO_AI" }}
{{- include "octo-mesh.system-env" . }}
{{ include "octo-mesh.broker-env" (dict "global" . "name" $name) }}
{{ include "octo-mesh.streamdata-env" (dict "global" . "name" $name) }}
- name: OCTO_AI__AUTHORITYURL
  value: {{ .Values.global.authUri }}
- name: OCTO_AI__ASSETSERVICESURL
  value: {{ .Values.global.assetRepositoryUri }}
- name: OCTO_AI__PUBLICURL
  value: {{ .Values.ai.publicUri }}
- name: OCTO_AI__AnthropicApiKey
  value: {{ .Values.ai.anthropic.anthropicApiKey }}
- name: OCTO_AI__AnthropicModel
  value: {{ .Values.ai.anthropic.anthropicModel }}
- name: OCTO_AI__MaxTokens
  value: {{ .Values.ai.anthropic.maxTokens | quote }}
- name: OCTO_AI__Temperature
  value: {{ .Values.ai.anthropic.temperature | quote }}
- name: OCTO_AI__INSTANCEPREFIX
  value: {{ .Values.global.instancePrefix }}
- name: OCTO_AI__OCTOMESHMCPSERVICEURL
  value: {{ .Values.global.octoMeshMcpServiceUrl }}
{{- end -}}

{{- define "octo-mesh-mcp.env" -}}
{{- $name := "OCTO_MCP" }}
{{- include "octo-mesh.system-env" . }}
{{ include "octo-mesh.broker-env" (dict "global" . "name" $name) }}
{{ include "octo-mesh.streamdata-env" (dict "global" . "name" $name) }}
- name: OCTO_MCP__AUTHORITYURL
  value: {{ .Values.global.authUri }}
- name: OCTO_MCP__PUBLICURL
  value: {{ .Values.mcp.publicUri }}
- name: OCTO_MCP__INSTANCEPREFIX
  value: {{ .Values.global.instancePrefix }}
{{- end -}}
