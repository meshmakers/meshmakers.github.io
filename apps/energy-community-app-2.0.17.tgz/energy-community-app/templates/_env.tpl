{{- define "octo-mesh.env" -}}
- name: CONFIG_ASSET_SERVICES
  value: {{ .Values.assetRepoUri }}
- name: CONFIG_ISSUER
  value: {{ printf "%s/" (trimSuffix "/" .Values.authUri) | quote }}
- name: CONFIG_CLIENT_ID
  value: {{ .Values.clientId }}
- name: CONFIG_ROOT_TENANT_ID
  value: {{ .Values.rootTenantId | default .Values.tenantId }}
- name: CONFIG_REPORTING_URL
  value: {{ .Values.reportingUri }}
- name: CONFIG_MESH_ADAPTER_URL
  value: {{ .Values.meshAdapterUri }}
- name: CONFIG_EDA_ADAPTER_URL
  value: {{ .Values.edaAdapterUri }}
{{- with .Values.dash0 }}
{{- if and .endpoint .authToken }}
- name: DASH0_ENDPOINT
  value: {{ .endpoint | quote }}
- name: DASH0_AUTH_TOKEN
  value: {{ .authToken | quote }}
{{- if .dataset }}
- name: DASH0_DATASET
  value: {{ .dataset | quote }}
{{- end }}
{{- if .environment }}
- name: DASH0_ENVIRONMENT
  value: {{ .environment | quote }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}
