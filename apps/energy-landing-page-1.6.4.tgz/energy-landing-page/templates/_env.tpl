{{/*
Env block consumed by deployment.yaml. Mirrors voest-app's `octo-mesh.env`
helper: the SPA's entrypoint.sh reads CONFIG_* variables and patches them
into /usr/share/nginx/html/assets/config.json before nginx starts. Order
of keys is deliberately deterministic so diffs stay stable.

assetServicesUrl is the single source of truth for both the REST and the
GraphQL endpoint on the SPA side — same convention as voest-app, the
legacy CONFIG_API_URL is intentionally not emitted.
*/}}
{{- define "octo-mesh.env" -}}
- name: CONFIG_TENANT_ID
  value: {{ .Values.tenantId }}
- name: CONFIG_CLIENT_ID
  value: {{ .Values.clientId }}
- name: CONFIG_AUTHORITY_URL
  value: {{ printf "%s/" (trimSuffix "/" .Values.authorityUrl) | quote }}
- name: CONFIG_ASSET_SERVICES_URL
  value: {{ .Values.assetServicesUrl }}
{{- if .Values.scope }}
- name: CONFIG_SCOPE
  value: {{ .Values.scope | quote }}
{{- end }}
{{- if .Values.meshAdapterUpstream }}
- name: CONFIG_MESH_ADAPTER_UPSTREAM
  value: {{ .Values.meshAdapterUpstream | quote }}
{{- end }}
{{/*
  Dash0 browser RUM. Two sources, like every other frontend chart here: a
  plaintext `dash0.authToken` for a hand-deployed install, and
  `secrets.dash0WebAuthToken` written by the Communication Operator as a
  secret-flagged value override — a {valueFrom: secretKeyRef:} MAP, not a
  string. The operator path wins; the endpoint always comes from
  `dash0.endpoint`, which the operator fills from its cluster-context layer.

  Gate: endpoint AND some token. Either alone leaves telemetry off, which is
  the same check init-telemetry.ts makes on config.json — so a half-configured
  cluster is a no-op rather than an SDK that fails at init.
*/}}
{{- $dash0 := .Values.dash0 | default dict }}
{{- $dash0Secret := (.Values.secrets | default dict).dash0WebAuthToken }}
{{- if and $dash0.endpoint (or $dash0Secret $dash0.authToken) }}
- name: DASH0_ENDPOINT
  value: {{ $dash0.endpoint | quote }}
- name: DASH0_AUTH_TOKEN
{{- if $dash0Secret }}
{{- if kindIs "map" $dash0Secret }}
  {{- toYaml $dash0Secret | nindent 2 }}
{{- else }}
  value: {{ $dash0Secret | quote }}
{{- end }}
{{- else }}
  value: {{ $dash0.authToken | quote }}
{{- end }}
{{- if $dash0.dataset }}
- name: DASH0_DATASET
  value: {{ $dash0.dataset | quote }}
{{- end }}
{{- if $dash0.environment }}
- name: DASH0_ENVIRONMENT
  value: {{ $dash0.environment | quote }}
{{- end }}
{{- end }}
{{- end }}
