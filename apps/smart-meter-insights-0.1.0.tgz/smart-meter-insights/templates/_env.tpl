{{/*
CONFIG_* environment for the nginx container. The image's entrypoint.sh reads
these and injects them into /usr/share/nginx/html/assets/config.json before
nginx starts. Mapping (env var -> config.json key, see docs/CONVENTIONS.md):

  CONFIG_ROOT_TENANT_ID      -> rootTenantId
  CONFIG_API_URL             -> apiUrl           (mesh adapter, /smi/* pipeline API)
  CONFIG_ISSUER              -> authorityUrl     (identity service, trailing slash)
  CONFIG_ASSET_SERVICES_URL  -> assetServicesUrl (asset repository, GraphQL + stream data)
  CONFIG_CLIENT_ID           -> clientId
  CONFIG_SCOPE               -> scope
  CONFIG_SHARE_BASE_URL      -> shareBaseUrl     (public base for /v/:token links)
  SMI_SHARE_TENANT           -> nginx /smi/ proxy target tenant (not config.json)

Keep this list in sync with src/smart-meter-insights/entrypoint.sh — a var the
entrypoint does not know is silently dropped, and a key it expects but does not
receive keeps the baked-in (local dev) value.
*/}}
{{- define "octo-mesh.env" -}}
- name: CONFIG_ASSET_SERVICES_URL
  value: {{ .Values.assetRepoUri }}
- name: CONFIG_ISSUER
  value: {{ printf "%s/" (trimSuffix "/" .Values.authUri) | quote }}
- name: CONFIG_CLIENT_ID
  value: {{ .Values.clientId }}
- name: CONFIG_SCOPE
  value: {{ .Values.scope | quote }}
- name: CONFIG_ROOT_TENANT_ID
  value: {{ .Values.rootTenantId }}
- name: CONFIG_API_URL
  value: {{ .Values.meshAdapterUri }}
{{- if .Values.shareBaseUrl }}
- name: CONFIG_SHARE_BASE_URL
  value: {{ .Values.shareBaseUrl | quote }}
{{- end }}
{{- if .Values.shareTenant }}
- name: SMI_SHARE_TENANT
  value: {{ .Values.shareTenant | quote }}
{{- end }}
{{- with .Values.dash0 }}
{{- if and .endpoint .authToken }}
- name: DASH0_ENDPOINT
  value: {{ .endpoint | quote }}
- name: DASH0_AUTH_TOKEN
  value: {{ .authToken | quote }}
{{- if .dataset }}
- name: DASH0_DATASET
  value: {{ .dataset | quote }}
{{- end }}
{{- if .environment }}
- name: DASH0_ENVIRONMENT
  value: {{ .environment | quote }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}
