{{/*
Env block consumed by deployment.yaml. Mirrors voest-app's `octo-mesh.env`
helper but adapted to the meshmakers app's runtime contract: the SPA's
entrypoint.sh reads CONFIG_* variables and patches them into
/usr/share/nginx/html/assets/config.json before nginx starts. Order of
keys is deliberately deterministic so diffs stay stable.

Unlike voest-app, this app keeps a separate apiUrl (Asset Repository REST +
GraphQL base) next to assetServicesUrl — both feed the OIDC/service client
config in configuration.service.ts. The adapter URLs are optional features
(Excel import via the Mesh adapter, finAPI web forms).
*/}}
{{- define "octo-mesh.env" -}}
- name: CONFIG_ROOT_TENANT_ID
  value: {{ .Values.rootTenantId | default .Values.tenantId }}
- name: CONFIG_CLIENT_ID
  value: {{ .Values.clientId }}
- name: CONFIG_AUTHORITY_URL
  value: {{ printf "%s/" (trimSuffix "/" .Values.authorityUrl) | quote }}
- name: CONFIG_API_URL
  value: {{ .Values.apiUrl }}
- name: CONFIG_ASSET_SERVICES_URL
  value: {{ .Values.assetServicesUrl }}
- name: CONFIG_BOT_SERVICES_URL
  value: {{ .Values.botServicesUrl }}
{{- if .Values.communicationServicesUrl }}
- name: CONFIG_COMMUNICATION_SERVICES_URL
  value: {{ .Values.communicationServicesUrl }}
{{- end }}
{{- if .Values.meshAdapterUrl }}
- name: CONFIG_MESH_ADAPTER_URL
  value: {{ .Values.meshAdapterUrl }}
{{- end }}
{{- if .Values.finApiAdapterUrl }}
- name: CONFIG_FINAPI_ADAPTER_URL
  value: {{ .Values.finApiAdapterUrl }}
{{- end }}
{{- if .Values.scope }}
- name: CONFIG_SCOPE
  value: {{ .Values.scope | quote }}
{{- end }}
{{/*
  Dash0 browser RUM. Two sources, because this chart is deployed both ways:
  by hand / by a values file (plaintext `dash0.authToken`), and by the
  Communication Operator, which projects the cluster's token as the
  secret-flagged override `secrets.dash0WebAuthToken` — a
  {valueFrom: secretKeyRef:} MAP, not a string. The operator path wins when
  both are present, and the endpoint always comes from `dash0.endpoint`, which
  the operator fills from its own context layer on every workload.

  Gate: endpoint AND some token. Either alone means telemetry stays off — the
  SPA makes the same check on config.json, so a half-configured cluster is a
  no-op rather than an SDK that fails at init.
*/}}
{{- $dash0 := .Values.dash0 | default dict }}
{{- $dash0Secret := (.Values.secrets | default dict).dash0WebAuthToken }}
{{- if and $dash0.endpoint (or $dash0Secret $dash0.authToken) }}
- name: DASH0_ENDPOINT
  value: {{ $dash0.endpoint | quote }}
- name: DASH0_AUTH_TOKEN
{{- if $dash0Secret }}
{{- if kindIs "map" $dash0Secret }}
  {{- toYaml $dash0Secret | nindent 2 }}
{{- else }}
  value: {{ $dash0Secret | quote }}
{{- end }}
{{- else }}
  value: {{ $dash0.authToken | quote }}
{{- end }}
{{- if $dash0.dataset }}
- name: DASH0_DATASET
  value: {{ $dash0.dataset | quote }}
{{- end }}
{{- if $dash0.environment }}
- name: DASH0_ENVIRONMENT
  value: {{ $dash0.environment | quote }}
{{- end }}
{{- end }}
{{- end }}
