{{/*
Env block consumed by deployment.yaml. The SPA's entrypoint.sh patches the
DASH0_* variables into /usr/share/nginx/html/assets/config.json before nginx
starts (Dash0 browser RUM is the page's only runtime configuration, AB#7434).
Order of keys is deliberately deterministic so diffs stay stable. When Dash0 is
not configured the list renders empty (`[]`).
*/}}
{{- define "octo-mesh.env" -}}
{{/*
  Dash0 browser RUM. Two sources, like every other frontend chart here: a
  plaintext `dash0.authToken` for a hand-deployed install, and
  `secrets.dash0WebAuthToken` written by the Communication Operator as a
  secret-flagged value override — a {valueFrom: secretKeyRef:} MAP, not a
  string. The operator path wins; the endpoint always comes from
  `dash0.endpoint`, which the operator fills from its cluster-context layer.

  Gate: endpoint AND some token. Either alone leaves telemetry off, which is
  the same check init-telemetry.ts makes on config.json — so a half-configured
  cluster is a no-op rather than an SDK that fails at init.
*/}}
{{- $dash0 := .Values.dash0 | default dict }}
{{- $dash0Secret := (.Values.secrets | default dict).dash0WebAuthToken }}
{{- if and $dash0.endpoint (or $dash0Secret $dash0.authToken) }}
- name: DASH0_ENDPOINT
  value: {{ $dash0.endpoint | quote }}
- name: DASH0_AUTH_TOKEN
{{- if $dash0Secret }}
{{- if kindIs "map" $dash0Secret }}
  {{- toYaml $dash0Secret | nindent 2 }}
{{- else }}
  value: {{ $dash0Secret | quote }}
{{- end }}
{{- else }}
  value: {{ $dash0.authToken | quote }}
{{- end }}
{{- if $dash0.dataset }}
- name: DASH0_DATASET
  value: {{ $dash0.dataset | quote }}
{{- end }}
{{- if $dash0.environment }}
- name: DASH0_ENVIRONMENT
  value: {{ $dash0.environment | quote }}
{{- end }}
{{- end }}
{{- end }}
