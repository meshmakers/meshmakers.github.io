{{/*
Env block consumed by deployment.yaml. Mirrors energy-community-app's
`octo-mesh.env` helper but adapted to voest-app's runtime contract:
the SPA's entrypoint.sh reads CONFIG_* variables and patches them into
/usr/share/nginx/html/assets/config.json before nginx starts. Order of
keys is deliberately deterministic so diffs stay stable.

assetServicesUrl is the single source of truth for both the REST and
the GraphQL endpoint on the SPA side — the legacy CONFIG_API_URL was
retired together with the apiUrl field in config.json.
*/}}
{{- define "octo-mesh.env" -}}
- name: CONFIG_TENANT_ID
  value: {{ .Values.tenantId }}
- name: CONFIG_CLIENT_ID
  value: {{ .Values.clientId }}
- name: CONFIG_AUTHORITY_URL
  value: {{ .Values.authorityUrl }}
- name: CONFIG_ASSET_SERVICES_URL
  value: {{ .Values.assetServicesUrl }}
- name: CONFIG_EDA_ADAPTER_URL
  value: {{ .Values.edaAdapterUrl }}
{{- if .Values.scope }}
- name: CONFIG_SCOPE
  value: {{ .Values.scope | quote }}
{{- end }}
{{- end }}
