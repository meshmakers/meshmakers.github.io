{{- define "octo-mesh.env" -}}
- name: CONFIG_ASSET_SERVICES
  value: {{ .Values.assetRepoUri }}
- name: CONFIG_ISSUER
  value: {{ printf "%s/" (trimSuffix "/" .Values.authUri) | quote }}
- name: CONFIG_CLIENT_ID
  value: {{ .Values.clientId }}
- name: CONFIG_SCOPE
  value: {{ .Values.scope | quote }}
- name: CONFIG_ROOT_TENANT_ID
  value: {{ .Values.rootTenantId | default .Values.tenantId }}
- name: CONFIG_REPORTING_URL
  value: {{ .Values.reportingUri }}
- name: CONFIG_MESH_ADAPTER_URL
  value: {{ .Values.meshAdapterUri }}
- name: CONFIG_EDA_ADAPTER_URL
  value: {{ .Values.edaAdapterUri }}
{{/* Always rendered, empty included: entrypoint.sh distinguishes an unset variable from one
     set to "", so privacyUri: "" is how a deployment says "render no link". */}}
- name: CONFIG_PRIVACY_URL
  value: {{ .Values.privacyUri | quote }}
- name: CONFIG_TERMS_URL
  value: {{ .Values.termsUri | quote }}
{{- if .Values.turnstileSiteKey }}
- name: CONFIG_TURNSTILE_SITE_KEY
  value: {{ .Values.turnstileSiteKey | quote }}
{{- end }}
{{/*
  Dash0 browser RUM. Two sources, because this chart is deployed both ways: by
  hand / by a values file (plaintext `dash0.authToken`), and by the Communication
  Operator, which projects the cluster's token as the secret-flagged override
  `secrets.dash0WebAuthToken` — a {valueFrom: secretKeyRef:} MAP, not a string.
  The operator path wins when both are present; the endpoint always comes from
  `dash0.endpoint`, which the operator fills from its cluster context layer.

  Gate: endpoint AND some token. Either alone leaves telemetry off — the SPA
  makes the same check on config.json, so a half-configured cluster is a no-op
  rather than an SDK that fails at init.
*/}}
{{- $dash0 := .Values.dash0 | default dict }}
{{- $dash0Secret := (.Values.secrets | default dict).dash0WebAuthToken }}
{{- if and $dash0.endpoint (or $dash0Secret $dash0.authToken) }}
- name: DASH0_ENDPOINT
  value: {{ $dash0.endpoint | quote }}
- name: DASH0_AUTH_TOKEN
{{- if $dash0Secret }}
{{- if kindIs "map" $dash0Secret }}
  {{- toYaml $dash0Secret | nindent 2 }}
{{- else }}
  value: {{ $dash0Secret | quote }}
{{- end }}
{{- else }}
  value: {{ $dash0.authToken | quote }}
{{- end }}
{{- if $dash0.dataset }}
- name: DASH0_DATASET
  value: {{ $dash0.dataset | quote }}
{{- end }}
{{- if $dash0.environment }}
- name: DASH0_ENVIRONMENT
  value: {{ $dash0.environment | quote }}
{{- end }}
{{- end }}
{{- end }}
