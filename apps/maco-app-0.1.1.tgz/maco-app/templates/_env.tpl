{{- define "octo-mesh.system-env" -}}
- name: OCTO_SYSTEM__SYSTEMDATABASENAME
  value: {{ .Values.systemDatabaseName }}
- name: OCTO_SYSTEM__DATABASEHOST
  value: {{ .Values.clusterDependencies.mongodbHost }}
{{ include "octo-mesh.secretEnv" (dict "envName" "OCTO_SYSTEM__DATABASEUSERPASSWORD" "value" .Values.secrets.databaseUser "legacyKey" "databaseUser" "context" .) }}
{{ include "octo-mesh.secretEnv" (dict "envName" "OCTO_SYSTEM__ADMINUSERPASSWORD" "value" .Values.secrets.databaseAdmin "legacyKey" "databaseAdmin" "context" .) }}
{{- end }}

{{- define "octo-mesh.broker-env" -}}
- name: {{ printf "%s__BROKERHOST" (upper .name) }}
  value: {{ .global.Values.clusterDependencies.rabbitMqHost }}
- name: {{ printf "%s__BROKERUSER" (upper .name) }}
  value: {{ .global.Values.clusterDependencies.rabbitMqUser }}
{{ include "octo-mesh.secretEnv" (dict "envName" (printf "%s__BROKERPASSWORD" (upper .name)) "value" .global.Values.secrets.rabbitmq "legacyKey" "rabbitmq" "context" .global) }}
{{- end }}

{{- define "octo-mesh.streamdata-env" -}}
- name: {{ printf "%s__STREAMDATAHOST" (upper .name) }}
  value: {{ .global.Values.clusterDependencies.streamDataHost }}
- name: {{ printf "%s__STREAMDATAUSER" (upper .name) }}
  value: {{ .global.Values.clusterDependencies.streamDataUser }}
{{ include "octo-mesh.secretEnv" (dict "envName" (printf "%s__STREAMDATAPASSWORD" (upper .name)) "value" .global.Values.secrets.streamDataPassword "legacyKey" "streamDataPassword" "context" .global) }}
{{- end }}


{{- define "octo-mesh.env" -}}
{{- $name := "OCTO_APP" }}
{{ include "octo-mesh.system-env" . }}
{{ include "octo-mesh.broker-env" (dict "global" . "name" $name) }} 
{{ include "octo-mesh.streamdata-env" (dict "global" . "name" $name) }}
- name: OCTO_APP__AUTHORITYURL
  value: {{ printf "%s/" (trimSuffix "/" .Values.authUri) | quote }}
- name: OCTO_APP__PUBLICURL
  value: {{ .Values.publicUri }}
- name: OCTO_APP__ASSETSERVICESURL
  value: {{ .Values.assetServicesUrl }}
- name: OCTO_APP__COMMUNICATIONCONTROLLERURL
  value: {{ .Values.communicationControllerUrl | quote }}
{{- if .Values.communicationClientId }}
- name: OCTO_APP__COMMUNICATIONCLIENTID
  value: {{ .Values.communicationClientId | quote }}
{{- end }}
{{- if .Values.secrets.communicationClientSecret }}
{{ include "octo-mesh.secretEnv" (dict "envName" "OCTO_APP__COMMUNICATIONCLIENTSECRET" "value" .Values.secrets.communicationClientSecret "legacyKey" "communicationClientSecret" "context" .) }}
{{- end }}
- name: OCTO_APP__TENANTID
  value: {{ .Values.tenantId }}
{{- if .Values.instancePrefix }}
- name: OCTO_APP__INSTANCEPREFIX
  value: {{ .Values.instancePrefix }}
{{- end }}
{{- end }}