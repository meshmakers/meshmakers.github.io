{{/*
Expand the name of the chart.
*/}}
{{- define "maco-app.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "maco-app.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "maco-app.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "maco-app.labels" -}}
helm.sh/chart: {{ include "maco-app.chart" . }}
{{ include "maco-app.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "maco-app.selectorLabels" -}}
app.kubernetes.io/name: {{ include "maco-app.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "maco-app.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "maco-app.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Check if a mandadory value exists
*/}}
{{- define "checkMandatoryValue" -}}
{{- if not .value -}}
{{- fail (printf "Value %s does not exist. Please define a corresponding value." .name) -}}
{{- end -}}
{{- end -}}

{{/*
Render an env entry whose value comes from a credential. Same dual-mode
shape as the adapter chart (octo-mesh-adapter/templates/_helpers.tpl):

  1. string (legacy): the chart packs it into the chart-owned
     `<fullname>-backend` Secret and renders a `valueFrom.secretKeyRef`
     pointing at that Secret with `legacyKey` as the key name.
  2. map with `valueFrom`: rendered straight through, so the operator
     (or External Secrets, etc.) can point at an externally-managed
     Secret. This is the path the central Communication Operator uses
     when injecting cluster credentials at deploy time.

Anything else fails the template — silent acceptance would mask typos.

Usage:
  {{ include "octo-mesh.secretEnv" (dict
       "envName"   "OCTO_SYSTEM__DATABASEUSERPASSWORD"
       "value"     .Values.secrets.databaseUser
       "legacyKey" "databaseUser"
       "context"   .
  ) }}
*/}}
{{- define "octo-mesh.secretEnv" -}}
- name: {{ .envName }}
{{- if kindIs "map" .value }}
  {{- if hasKey .value "valueFrom" }}
  {{- toYaml .value | nindent 2 }}
  {{- else }}
  {{- fail (printf "secrets.%s must be a string or a {valueFrom: secretKeyRef: ...} map" .legacyKey) }}
  {{- end }}
{{- else if .value }}
  valueFrom:
    secretKeyRef:
      name: {{ printf "%s-backend" (include "maco-app.fullname" .context) }}
      key: {{ .legacyKey }}
{{- else }}
  {{- fail (printf "secrets.%s must be set (either a plaintext string or a valueFrom map)" .legacyKey) }}
{{- end }}
{{- end -}}

{{/*
Returns "true" when any of the secret fields used by the chart-owned
`<fullname>-backend` Secret is a plaintext string. Used by secret.yaml
to skip emitting the resource entirely when every value is sourced
externally via valueFrom.
*/}}
{{- define "octo-mesh.hasPlaintextBackendSecret" -}}
{{- $s := .Values.secrets -}}
{{- if and $s.databaseUser (not (kindIs "map" $s.databaseUser)) -}}true
{{- else if and $s.databaseAdmin (not (kindIs "map" $s.databaseAdmin)) -}}true
{{- else if and $s.rabbitmq (not (kindIs "map" $s.rabbitmq)) -}}true
{{- else if and $s.streamDataPassword (not (kindIs "map" $s.streamDataPassword)) -}}true
{{- else if and $s.communicationClientSecret (not (kindIs "map" $s.communicationClientSecret)) -}}true
{{- end -}}
{{- end -}}
