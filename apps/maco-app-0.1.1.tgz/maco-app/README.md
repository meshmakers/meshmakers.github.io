# MACO App — deployment configuration

Things that must be set up **outside the container image** for a MACO deployment to
work. All of it is done through **Refinery Studio** (RtApplication ValueOverride /
ValuesYaml) plus a one-time identity client, except where noted.

## Communication Controller service account (required — AB#4493)

MACO calls the Communication Controller (CC) server-to-server for
`DeployDataFlow` / `UndeployDataFlow` / trigger sync (the simulator flow). It
authenticates with its **own client-credentials service account** — it does **not**
forward the end-user's token (that token was pinned by the SDK and went stale after
~1h, causing HTTP 401 until a MACO restart).

Without this setup, those calls fail with **HTTP 401 / `invalid_client`** (MACO
itself still runs; only the deploy endpoints fail). It is a **coordinated** change:
do steps 1–2 **before** rolling the image, or the endpoints break consistently.

### 1. Create the identity client (one-time, per environment)

Create a **ClientCredentials** client **in the SAME tenant** as the deployment's
`tenantId` (⚠️ wrong tenant → `invalid_client`), with the `octo_api` scope. Via
`octo-cli` (logged in to that environment's identity, as an admin):

```bash
octo-cli -c AddClientCredentialsClient --clientId "maco-app-service" --name "MACO App Service" --secret "<STRONG_SECRET>"
octo-cli -c AddScopeToClient           --clientId "maco-app-service" --name "octo_api"
```

Keep `<STRONG_SECRET>` — it cannot be read back later (identity stores it hashed).
Prefer an alphanumeric value to avoid shell/quoting mismatches.

### 2. Set the ValueOverrides on the MACO RtApplication (Refinery Studio)

On the MACO application entity, add these overrides (same mechanism as
`communicationControllerUrl`):

| Override key                        | Value                         | Secret? |
|-------------------------------------|-------------------------------|---------|
| `communicationClientId`             | `maco-app-service`            | no      |
| `secrets.communicationClientSecret` | the **plaintext** `<STRONG_SECRET>` from step 1 | **yes** (secret-flagged → encrypted at rest, sourced via a Secret / `secretKeyRef`, never rendered into the Deployment) |

`communicationClientId` is the client's `ClientId` string. The secret is set under the
chart's `secrets` group (like the other credentials), so it is delivered via a
Kubernetes Secret and never appears as plaintext in the rendered Deployment. It is the
plaintext secret you assigned in step 1 — **not** something you read from Studio
(secrets are hashed there); if you lost it, set a new one and use that.

These map to env vars `OCTO_APP__COMMUNICATIONCLIENTID` /
`OCTO_APP__COMMUNICATIONCLIENTSECRET` (see `templates/_env.tpl`). MACO acquires and
auto-refreshes its token from the identity service at `authUri`, scoped to
`tenantId` (`acr_values=tenant:<tenantId>`).

### 3. Deploy

Roll the new image and redeploy the application.

### Verify

- MACO log (Warning, visible in Release): `Communication Controller service-account
  token acquired for client maco-app-service, expires …`
- `DeployDataFlow` returns **204** (adapter must be online).
- If **403** instead of 401 → the client is missing a scope/role; grant the
  full-access scope for CC.

## Other required config (already wired)

- `authUri` → `OCTO_APP__AUTHORITYURL` (identity service).
- `communicationControllerUrl` → `OCTO_APP__COMMUNICATIONCONTROLLERURL`
  (usually `"{{service.communication}}"` in ValuesYaml, resolved by the
  Communication Operator).
- `tenantId` → `OCTO_APP__TENANTID` (one tenant per deployment).
