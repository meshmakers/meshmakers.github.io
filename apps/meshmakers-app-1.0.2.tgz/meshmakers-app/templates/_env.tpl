{{/*
Env block consumed by deployment.yaml. Mirrors voest-app's `octo-mesh.env`
helper but adapted to the meshmakers app's runtime contract: the SPA's
entrypoint.sh reads CONFIG_* variables and patches them into
/usr/share/nginx/html/assets/config.json before nginx starts. Order of
keys is deliberately deterministic so diffs stay stable.

Unlike voest-app, this app keeps a separate apiUrl (Asset Repository REST +
GraphQL base) next to assetServicesUrl — both feed the OIDC/service client
config in configuration.service.ts. The adapter URLs are optional features
(Excel import via the Mesh adapter, finAPI web forms).
*/}}
{{- define "octo-mesh.env" -}}
- name: CONFIG_TENANT_ID
  value: {{ .Values.tenantId }}
- name: CONFIG_CLIENT_ID
  value: {{ .Values.clientId }}
- name: CONFIG_AUTHORITY_URL
  value: {{ printf "%s/" (trimSuffix "/" .Values.authorityUrl) | quote }}
- name: CONFIG_API_URL
  value: {{ .Values.apiUrl }}
- name: CONFIG_ASSET_SERVICES_URL
  value: {{ .Values.assetServicesUrl }}
- name: CONFIG_BOT_SERVICES_URL
  value: {{ .Values.botServicesUrl }}
{{- if .Values.meshAdapterUrl }}
- name: CONFIG_MESH_ADAPTER_URL
  value: {{ .Values.meshAdapterUrl }}
{{- end }}
{{- if .Values.finApiAdapterUrl }}
- name: CONFIG_FINAPI_ADAPTER_URL
  value: {{ .Values.finApiAdapterUrl }}
{{- end }}
{{- if .Values.scope }}
- name: CONFIG_SCOPE
  value: {{ .Values.scope | quote }}
{{- end }}
{{- end }}
