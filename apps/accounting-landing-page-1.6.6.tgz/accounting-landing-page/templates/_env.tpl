{{/*
Dash0 browser RUM environment for the static landing pages.

The page carries no config.json — /docker-entrypoint.d/40-dash0-telemetry.sh in
the image turns these four variables into /assets/telemetry.js at container
start. Nothing is emitted unless an endpoint AND a token are configured, which
is what keeps a cluster without Dash0 byte-identical to before.

Two sources for the token, like every other frontend chart here: a plaintext
`dash0.authToken` for a hand-deployed install, and `secrets.dash0WebAuthToken`
written by the Communication Operator as a secret-flagged value override — a
{valueFrom: secretKeyRef:} MAP rather than a string. The operator path wins.
The endpoint always comes from `dash0.endpoint`, which the operator fills from
its own cluster-context layer on every workload it deploys.

DASH0_SERVICE_NAME is NOT set here: the image bakes it in, so each page keeps a
distinct service.name in the Dash0 service map without any chart configuration.
*/}}
{{- define "accounting-landing-page.dash0Env" -}}
{{- $dash0 := .Values.dash0 | default dict }}
{{- $dash0Secret := (.Values.secrets | default dict).dash0WebAuthToken }}
{{- if and $dash0.endpoint (or $dash0Secret $dash0.authToken) }}
- name: DASH0_ENDPOINT
  value: {{ $dash0.endpoint | quote }}
- name: DASH0_AUTH_TOKEN
{{- if $dash0Secret }}
{{- if kindIs "map" $dash0Secret }}
  {{- toYaml $dash0Secret | nindent 2 }}
{{- else }}
  value: {{ $dash0Secret | quote }}
{{- end }}
{{- else }}
  value: {{ $dash0.authToken | quote }}
{{- end }}
{{- if $dash0.dataset }}
- name: DASH0_DATASET
  value: {{ $dash0.dataset | quote }}
{{- end }}
{{- if $dash0.environment }}
- name: DASH0_ENVIRONMENT
  value: {{ $dash0.environment | quote }}
{{- end }}
{{- end }}
{{- end -}}
