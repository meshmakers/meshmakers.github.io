{{/*
Env block consumed by deployment.yaml. Mirrors voest-app's `octo-mesh.env`
helper: the SPA's entrypoint.sh reads CONFIG_* variables and patches them
into /usr/share/nginx/html/assets/config.json before nginx starts. Order
of keys is deliberately deterministic so diffs stay stable.

assetServicesUrl is the single source of truth for both the REST and the
GraphQL endpoint on the SPA side — same convention as voest-app, the
legacy CONFIG_API_URL is intentionally not emitted.
*/}}
{{- define "octo-mesh.env" -}}
- name: CONFIG_TENANT_ID
  value: {{ .Values.tenantId }}
- name: CONFIG_CLIENT_ID
  value: {{ .Values.clientId }}
- name: CONFIG_AUTHORITY_URL
  value: {{ .Values.authorityUrl }}
- name: CONFIG_ASSET_SERVICES_URL
  value: {{ .Values.assetServicesUrl }}
{{- if .Values.scope }}
- name: CONFIG_SCOPE
  value: {{ .Values.scope | quote }}
{{- end }}
{{- end }}
