{{- define "octo-mesh.env" -}}
- name: CONFIG_ASSET_SERVICES
  value: {{ .Values.assetRepoUri }}
- name: CONFIG_ISSUER
  value: {{ printf "%s/" (trimSuffix "/" .Values.authUri) | quote }}
- name: CONFIG_CLIENT_ID
  value: {{ .Values.clientId }}
- name: CONFIG_TENANT_ID
  value: {{ .Values.tenantId }}
- name: CONFIG_REPORTING_URL
  value: {{ .Values.reportingUri }}
- name: CONFIG_MESH_ADAPTER_URL
  value: {{ .Values.meshAdapterUri }}
- name: CONFIG_EDA_ADAPTER_URL
  value: {{ .Values.edaAdapterUri }}
{{- end }}
